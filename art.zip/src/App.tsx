import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './lib/AuthContext';
import { Toaster } from 'sonner';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import AdminDashboard from './pages/AdminDashboard';
import ClientView from './pages/ClientView';
import Assessments from './pages/Assessments';
import Feedback from './pages/Feedback';
import Billing from './pages/Billing';
import Contract from './pages/Contract';
import Messages from './pages/Messages';
import Sidebar from './components/layout/Sidebar';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ProtectedRoute = ({ children, adminOnly = false }: { children: React.ReactNode, adminOnly?: boolean }) => {
  const { user, profile, loading, isAdmin } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  if (loading) return <div className="flex items-center justify-center h-screen">Loading...</div>;
  if (!user) return <Navigate to="/login" />;
  if (adminOnly && !isAdmin) return <Navigate to="/" />;

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-[#FDFCFB]">
      {/* Mobile Header */}
      <header className="lg:hidden flex items-center justify-between p-4 border-b border-[#e5e5e5] bg-white sticky top-0 z-40">
        <h1 className="text-xl font-serif tracking-tight">ART</h1>
        <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
          <SheetTrigger render={
            <Button variant="ghost" size="icon">
              <Menu size={24} />
            </Button>
          } />
          <SheetContent side="left" className="p-0 w-72">
            <Sidebar className="w-full border-none" onClose={() => setIsMobileMenuOpen(false)} />
          </SheetContent>
        </Sheet>
      </header>

      {/* Desktop Sidebar */}
      <Sidebar className="hidden lg:flex" />

      <main className="flex-1 p-4 md:p-8 overflow-y-auto relative">
        {children}
        <footer className="mt-20 py-8 border-t border-[#e5e5e5] text-center">
          <p className="text-[10px] text-muted-foreground uppercase tracking-widest">
            ART CRM v1.0.2 • Updated: {new Date().toLocaleString()}
          </p>
        </footer>
      </main>
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          
          <Route path="/" element={
            <ProtectedRoute>
              <DashboardWrapper />
            </ProtectedRoute>
          } />

          <Route path="/assessments" element={
            <ProtectedRoute>
              <Assessments />
            </ProtectedRoute>
          } />

          <Route path="/feedback" element={
            <ProtectedRoute>
              <Feedback />
            </ProtectedRoute>
          } />

          <Route path="/billing" element={
            <ProtectedRoute>
              <Billing />
            </ProtectedRoute>
          } />

          <Route path="/contract" element={
            <ProtectedRoute>
              <Contract />
            </ProtectedRoute>
          } />

          <Route path="/contract/:contractId" element={
            <ProtectedRoute>
              <Contract />
            </ProtectedRoute>
          } />

          <Route path="/messages" element={
            <ProtectedRoute>
              <Messages />
            </ProtectedRoute>
          } />

          {/* Admin Routes */}
          <Route path="/admin" element={
            <ProtectedRoute adminOnly>
              <AdminDashboard />
            </ProtectedRoute>
          } />
          
          <Route path="/admin/client/:clientId" element={
            <ProtectedRoute adminOnly>
              <ClientView />
            </ProtectedRoute>
          } />

        </Routes>
      </Router>
      <Toaster position="top-right" />
    </AuthProvider>
  );
}

function DashboardWrapper() {
  const { isAdmin } = useAuth();
  return isAdmin ? <Navigate to="/admin" /> : <Dashboard />;
}
