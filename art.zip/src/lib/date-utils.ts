import { format, isValid } from 'date-fns';

/**
 * Safely formats a date string or Date object.
 * Returns a fallback string if the date is invalid.
 */
export function safeFormatDate(date: string | Date | undefined | null, formatStr: string, fallback: string = 'N/A'): string {
  if (!date) return fallback;
  
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  
  if (!isValid(dateObj)) return fallback;
  
  return format(dateObj, formatStr);
}
