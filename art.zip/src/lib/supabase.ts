import { createClient } from '@supabase/supabase-js';

let supabaseUrl = (import.meta.env.VITE_SUPABASE_URL || '').trim();
let supabaseAnonKey = (import.meta.env.VITE_SUPABASE_ANON_KEY || '').trim();

// 1. Clean up common copy-paste errors (like "VITE_SUPABASE_URL = ...")
const clean = (val: string) => val.split('=').pop()?.trim().replace(/['";]/g, '') || '';
supabaseUrl = clean(supabaseUrl);
supabaseAnonKey = clean(supabaseAnonKey);

// 2. Identify keys vs URLs
const isKey = (val: string) => val.startsWith('eyJ') || val.length > 100 || val.includes('sb_publishable');
const isUrl = (val: string) => val.startsWith('http') || val.includes('.supabase.co');

// 3. Self-healing: If items are swapped, swap them back
if (isKey(supabaseUrl) && isUrl(supabaseAnonKey)) {
  console.warn("Supabase Config: Swapped URL and Key detected. Automatically correcting.");
  const temp = supabaseUrl;
  supabaseUrl = supabaseAnonKey;
  supabaseAnonKey = temp;
}

// 4. Recovery: If URL is missing or still a key, use the known Project ID
const knownProjectId = 'ejrjhkuozaxbzvkwaroa';
if (!isUrl(supabaseUrl) || isKey(supabaseUrl)) {
  console.warn("Supabase Config: URL looks invalid. Using hardcoded recovery URL.");
  supabaseUrl = `https://${knownProjectId}.supabase.co`;
}

// 5. Final fallback for URL formatting
if (supabaseUrl && !supabaseUrl.startsWith('http')) {
  supabaseUrl = `https://${supabaseUrl}`;
}

if (!supabaseUrl || !supabaseAnonKey) {
  console.error("Supabase configuration is missing. VITE_SUPABASE_URL or VITE_SUPABASE_ANON_KEY not set.");
} else {
  console.log(`Supabase initialized with URL: ${supabaseUrl}`);
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
