import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { AssessmentTemplate, ClientAssessment, ClientAssessmentQuestion } from '../types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Plus, 
  Trash2, 
  Edit2, 
  Save, 
  X, 
  ClipboardCheck,
  FileDown,
  Clock,
  CheckCircle2,
  AlertCircle,
  PlusCircle,
  Upload
} from 'lucide-react';
import { toast } from 'sonner';
import { safeFormatDate } from '../lib/date-utils';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter,
  DialogDescription
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';

interface ClientAssessmentManagerProps {
  clientId: string;
  onUploadReport?: (assessmentId: string) => void;
}

export default function ClientAssessmentManager({ clientId, onUploadReport }: ClientAssessmentManagerProps) {
  const [templates, setTemplates] = useState<AssessmentTemplate[]>([]);
  const [clientAssessments, setClientAssessments] = useState<ClientAssessment[]>([]);
  const [isAssignOpen, setIsAssignOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingAssessment, setEditingAssessment] = useState<ClientAssessment | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      // Fetch templates
      const { data: templatesData } = await supabase
        .from('assessment_templates')
        .select('*')
        .order('created_at', { ascending: false });
      setTemplates(templatesData || []);

      // Fetch client's assessments
      const { data: assessmentsData } = await supabase
        .from('client_assessments')
        .select('*')
        .eq('client_id', clientId)
        .order('updated_at', { ascending: false });
      setClientAssessments(assessmentsData || []);
    };

    fetchData();
  }, [clientId]);

  const handleAssignTemplate = async (template: AssessmentTemplate) => {
    try {
      const { error } = await supabase.from('client_assessments').insert({
        client_id: clientId,
        template_id: template.id,
        title: template.title,
        description: template.description,
        questions: template.questions.map(q => ({
          id: q.id,
          text: q.text,
          options: q.options,
          answer: ''
        })),
        status: 'pending',
        updated_at: new Date().toISOString()
      });

      if (error) throw error;
      
      toast.success(`Assigned "${template.title}" to client`);
      setIsAssignOpen(false);
      
      // Refresh
      const { data } = await supabase.from('client_assessments').select('*').eq('client_id', clientId).order('updated_at', { ascending: false });
      setClientAssessments(data || []);
    } catch (error) {
      console.error('Error assigning assessment:', error);
      toast.error('Failed to assign assessment');
    }
  };

  const handleUpdateAssessment = async () => {
    if (!editingAssessment) return;
    try {
      const { error } = await supabase.from('client_assessments').update({
        title: editingAssessment.title,
        description: editingAssessment.description,
        questions: editingAssessment.questions,
        updated_at: new Date().toISOString()
      }).eq('id', editingAssessment.id);
      
      if (error) throw error;
      
      toast.success('Assessment updated');
      setIsEditOpen(false);
      setEditingAssessment(null);
      
      // Refresh
      const { data } = await supabase.from('client_assessments').select('*').eq('client_id', clientId).order('updated_at', { ascending: false });
      setClientAssessments(data || []);
    } catch (error) {
      console.error('Error updating assessment:', error);
      toast.error('Failed to update assessment');
    }
  };

  const handleDeleteAssessment = async (id: string) => {
    if (!confirm('Are you sure you want to remove this assessment from the client?')) return;
    try {
      const { error } = await supabase.from('client_assessments').delete().eq('id', id);
      if (error) throw error;
      toast.success('Assessment removed');
      setClientAssessments(clientAssessments.filter(a => a.id !== id));
    } catch (error) {
      toast.error('Failed to remove assessment');
    }
  };

  const handleAddQuestion = () => {
    if (!editingAssessment) return;
    const newQuestion: ClientAssessmentQuestion = {
      id: Date.now().toString(),
      text: '',
      options: ['Yes', 'No', 'Partially'],
      answer: ''
    };
    setEditingAssessment({
      ...editingAssessment,
      questions: [...editingAssessment.questions, newQuestion]
    });
  };

  const handleRemoveQuestion = (id: string) => {
    if (!editingAssessment) return;
    setEditingAssessment({
      ...editingAssessment,
      questions: editingAssessment.questions.filter(q => q.id !== id)
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-serif">Client Assessments</h3>
        <Dialog open={isAssignOpen} onOpenChange={setIsAssignOpen}>
          <DialogTrigger 
            render={
              <Button className="bg-[#1a1a1a] text-white rounded-full gap-2">
                <PlusCircle size={16} />
                Assign New Assessment
              </Button>
            }
          />
          <DialogContent className="sm:max-w-[500px] font-sans">
            <DialogHeader>
              <DialogTitle className="font-serif text-2xl">Assign Assessment Template</DialogTitle>
              <DialogDescription>Select a template to assign to this client.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              {templates.map(template => (
                <div 
                  key={template.id} 
                  className="p-4 border rounded-xl hover:bg-slate-50 cursor-pointer transition-colors flex items-center justify-between group"
                  onClick={() => handleAssignTemplate(template)}
                >
                  <div>
                    <p className="font-medium">{template.title}</p>
                    <p className="text-xs text-muted-foreground">{template.questions.length} Questions</p>
                  </div>
                  <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
                    Assign
                  </Button>
                </div>
              ))}
              {templates.length === 0 && (
                <div className="text-center py-8 text-muted-foreground italic">
                  No templates available. Create templates in the Assessments section.
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {clientAssessments.map((assessment) => (
          <Card key={assessment.id} className="border-[#e5e5e5] shadow-sm group">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div className="space-y-1">
                <CardTitle className="font-serif text-lg">{assessment.title}</CardTitle>
                <div className="flex items-center gap-2">
                  <Badge variant={assessment.status === 'completed' ? "default" : "secondary"} className="rounded-full text-[10px] uppercase tracking-widest">
                    {assessment.status}
                  </Badge>
                  <span className="text-[10px] text-muted-foreground uppercase tracking-widest">
                    {assessment.questions.length} Qs
                  </span>
                </div>
              </div>
              <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button variant="ghost" size="icon" onClick={() => {
                  setEditingAssessment(assessment);
                  setIsEditOpen(true);
                }}>
                  <Edit2 size={14} />
                </Button>
                <Button variant="ghost" size="icon" className="text-destructive" onClick={() => handleDeleteAssessment(assessment.id)}>
                  <Trash2 size={14} />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground line-clamp-2 mb-4">{assessment.description}</p>
              <div className="flex items-center justify-between mt-4 pt-4 border-t border-[#f5f5f5]">
                <div className="flex items-center gap-2 text-[10px] text-muted-foreground uppercase tracking-widest">
                  <Clock size={12} />
                  Updated {safeFormatDate(assessment.updated_at, 'MMM d')}
                </div>
                {assessment.status === 'completed' && assessment.report_url ? (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="rounded-full h-8 text-[10px] uppercase tracking-widest gap-2"
                    onClick={() => window.open(assessment.report_url, '_blank')}
                  >
                    <FileDown size={12} /> Report
                  </Button>
                ) : (
                  onUploadReport && (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="rounded-full h-8 text-[10px] uppercase tracking-widest gap-2 border-blue-200 text-blue-600 hover:bg-blue-50"
                      onClick={() => onUploadReport(assessment.id)}
                    >
                      <Upload size={12} /> Upload Report
                    </Button>
                  )
                )}
              </div>
            </CardContent>
          </Card>
        ))}
        {clientAssessments.length === 0 && (
          <div className="col-span-full p-12 text-center border border-dashed border-[#e5e5e5] rounded-2xl text-muted-foreground font-light italic">
            No assessments assigned to this client yet.
          </div>
        )}
      </div>

      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto font-sans">
          <DialogHeader>
            <DialogTitle className="font-serif text-2xl">Customize Client Assessment</DialogTitle>
            <DialogDescription>Modify questions specifically for this client.</DialogDescription>
          </DialogHeader>
          {editingAssessment && (
            <div className="space-y-6 py-4">
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest font-semibold">Title</label>
                <Input 
                  value={editingAssessment.title}
                  onChange={e => setEditingAssessment({...editingAssessment, title: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest font-semibold">Description</label>
                <Textarea 
                  value={editingAssessment.description}
                  onChange={e => setEditingAssessment({...editingAssessment, description: e.target.value})}
                />
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <label className="text-xs uppercase tracking-widest font-semibold">Questions</label>
                  <Button variant="outline" size="sm" onClick={handleAddQuestion} className="rounded-full gap-2">
                    <Plus size={14} /> Add Question
                  </Button>
                </div>

                <div className="space-y-4">
                  {editingAssessment.questions.map((q, qIdx) => (
                    <div key={q.id} className="p-4 border rounded-xl bg-slate-50/50 space-y-4">
                      <div className="flex gap-4">
                        <div className="flex-1 space-y-2">
                          <label className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Question {qIdx + 1}</label>
                          <Input 
                            value={q.text}
                            onChange={e => {
                              const newQs = [...editingAssessment.questions];
                              newQs[qIdx] = { ...q, text: e.target.value };
                              setEditingAssessment({...editingAssessment, questions: newQs});
                            }}
                          />
                        </div>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="mt-6 text-destructive"
                          onClick={() => handleRemoveQuestion(q.id)}
                        >
                          <Trash2 size={16} />
                        </Button>
                      </div>
                      
                      <div className="space-y-2">
                        <label className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Options</label>
                        <div className="grid grid-cols-2 gap-2">
                          {q.options.map((opt, oIdx) => (
                            <div key={oIdx} className="flex gap-2">
                              <Input 
                                value={opt}
                                onChange={e => {
                                  const newQs = [...editingAssessment.questions];
                                  const newOpts = [...q.options];
                                  newOpts[oIdx] = e.target.value;
                                  newQs[qIdx] = { ...q, options: newOpts };
                                  setEditingAssessment({...editingAssessment, questions: newQs});
                                }}
                                className="h-8 text-xs"
                              />
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-8 w-8 text-destructive"
                                onClick={() => {
                                  const newQs = [...editingAssessment.questions];
                                  const newOpts = q.options.filter((_, i) => i !== oIdx);
                                  newQs[qIdx] = { ...q, options: newOpts };
                                  setEditingAssessment({...editingAssessment, questions: newQs});
                                }}
                              >
                                <X size={12} />
                              </Button>
                            </div>
                          ))}
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => {
                              const newQs = [...editingAssessment.questions];
                              newQs[qIdx] = { ...q, options: [...q.options, ''] };
                              setEditingAssessment({...editingAssessment, questions: newQs});
                            }}
                            className="h-8 text-[10px] uppercase tracking-widest border border-dashed"
                          >
                            <Plus size={10} className="mr-1" /> Add Option
                          </Button>
                        </div>
                      </div>

                      {q.answer && (
                        <div className="pt-2 border-t border-slate-200">
                          <p className="text-[10px] uppercase tracking-widest font-bold text-green-600">Client Answer</p>
                          <p className="text-sm font-medium">{q.answer}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button onClick={handleUpdateAssessment} className="w-full bg-[#1a1a1a] text-white rounded-full h-12">
              Save Customizations
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
