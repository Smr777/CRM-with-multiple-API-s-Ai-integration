import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { uploadFile, UploadMetadata } from '../services/uploadService';

interface FileUploadProps {
  title: string;
  bucket?: string;
  path: string;
  metadata: UploadMetadata;
  onUploadSuccess: (url: string) => void;
}

export const FileUpload: React.FC<FileUploadProps> = ({ title, bucket = 'documents', path, metadata, onUploadSuccess }) => {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setProgress(0);

    try {
      const downloadUrl = await uploadFile(file, bucket, path, metadata, (p) => setProgress(p));
      toast.success(`${title} uploaded successfully`);
      onUploadSuccess(downloadUrl);
    } catch (error) {
      console.error('Upload error:', error);
      toast.error(`Failed to upload ${title}. Please try again.`);
    } finally {
      setUploading(false);
      setProgress(0);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <input 
          type="file" 
          onChange={handleFileChange} 
          disabled={uploading}
          className="mb-4"
        />
        {uploading && (
          <div className="space-y-2">
            <Progress value={progress} />
            <p className="text-sm text-muted-foreground">Uploading... {Math.round(progress)}%</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
