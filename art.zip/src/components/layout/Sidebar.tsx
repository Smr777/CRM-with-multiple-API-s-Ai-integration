import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../lib/AuthContext';
import { supabase } from '../../lib/supabase';
import { 
  LayoutDashboard, 
  ClipboardCheck, 
  MessageSquare, 
  CreditCard, 
  FileText, 
  LogOut,
  Users,
  Bell,
  Settings
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';

import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';

export default function Sidebar({ className, onClose }: { className?: string, onClose?: () => void }) {
  const { isAdmin, profile } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/login');
    if (onClose) onClose();
  };

  const navItems = isAdmin ? [
    { icon: LayoutDashboard, label: 'Admin Panel', path: '/admin?view=overview' },
    { icon: Users, label: 'Clients', path: '/admin?view=clients' },
    { icon: ClipboardCheck, label: 'Assessments', path: '/admin?view=assessments' },
    { icon: MessageSquare, label: 'Feedback', path: '/admin?view=feedback' },
    { icon: Bell, label: 'Notices', path: '/admin?view=notices' },
    { icon: MessageSquare, label: 'Messages', path: '/admin?view=messages' },
  ] : [
    { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
    { icon: ClipboardCheck, label: 'Assessments', path: '/assessments' },
    { icon: MessageSquare, label: 'Feedback', path: '/feedback' },
    { icon: CreditCard, label: 'Billing', path: '/billing' },
    { icon: FileText, label: 'Contract', path: '/contract' },
    { icon: Bell, label: 'Messages', path: '/messages' },
  ];

  return (
    <aside className={cn(
      "w-72 border-r border-[#e5e5e5] bg-white flex flex-col h-screen sticky top-0 overflow-y-auto",
      className
    )}>
      <div className="p-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-serif tracking-tight">ART</h1>
          <p className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground mt-1">Management</p>
        </div>
      </div>

      <nav className="flex-1 px-4 space-y-1">
        {navItems.map((item) => (
          <NavLink
            key={item.label}
            to={item.path}
            onClick={onClose}
            className={({ isActive }) => cn(
              "flex items-center gap-3 px-4 py-3 rounded-lg text-sm transition-all duration-200",
              isActive 
                ? "bg-[#1a1a1a] text-white shadow-md" 
                : "text-muted-foreground hover:bg-[#f5f5f5] hover:text-[#1a1a1a]"
            )}
          >
            <item.icon size={18} strokeWidth={1.5} />
            <span className="font-medium tracking-wide">{item.label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="p-6 space-y-4">
        <Separator className="bg-[#e5e5e5]" />
        <Dialog>
          <DialogTrigger 
            render={
              <button type="button" className="w-full flex items-center gap-3 px-2 cursor-pointer hover:bg-[#f5f5f5] py-2 rounded-lg transition-colors text-left">
                <div className="w-8 h-8 rounded-full bg-[#f5f5f5] border border-[#e5e5e5] flex items-center justify-center text-xs font-serif">
                  {profile?.display_name?.[0] || 'U'}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">{profile?.display_name || 'User'}</p>
                  <div className="flex items-center gap-1">
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{isAdmin ? 'admin' : (profile?.role || 'client')}</p>
                    {isAdmin && <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />}
                  </div>
                </div>
              </button>
            }
          />
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle className="font-serif text-2xl">Your Profile</DialogTitle>
            </DialogHeader>
            <div className="space-y-6 py-4">
              <div className="flex flex-col items-center gap-4">
                <div className="w-20 h-20 rounded-full bg-[#f5f5f5] border border-[#e5e5e5] flex items-center justify-center text-3xl font-serif">
                  {profile?.display_name?.[0] || 'U'}
                </div>
                <div className="text-center">
                  <h3 className="text-xl font-medium">{profile?.display_name}</h3>
                  <p className="text-sm text-muted-foreground">{profile?.email}</p>
                </div>
              </div>
              <Separator />
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="space-y-1">
                  <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold">Role</p>
                  <p className="capitalize">{isAdmin ? 'admin' : (profile?.role || 'client')}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold">Client Type</p>
                  <p className="capitalize">{profile?.client_type || 'N/A'}</p>
                </div>
                <div className="space-y-1 col-span-2">
                  <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold">User ID</p>
                  <p className="font-mono text-[10px] break-all">{profile?.id}</p>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
        <Button 
          variant="ghost" 
          onClick={handleLogout}
          className="w-full justify-start gap-3 text-muted-foreground hover:text-destructive hover:bg-destructive/5"
        >
          <LogOut size={18} strokeWidth={1.5} />
          <span className="text-sm font-medium">Sign Out</span>
        </Button>
      </div>
    </aside>
  );
}
