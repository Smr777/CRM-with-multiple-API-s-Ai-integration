import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { AssessmentTemplate, AssessmentQuestion } from '../types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Plus, 
  Trash2, 
  Edit2, 
  Save, 
  X, 
  ChevronDown, 
  ChevronUp,
  Settings2,
  ListPlus
} from 'lucide-react';
import { toast } from 'sonner';
import { safeFormatDate } from '../lib/date-utils';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter
} from '@/components/ui/dialog';

export default function AssessmentManager() {
  const [templates, setTemplates] = useState<AssessmentTemplate[]>([]);
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [formData, setFormData] = useState<Partial<AssessmentTemplate>>({
    title: '',
    description: '',
    questions: []
  });

  useEffect(() => {
    const fetchTemplates = async () => {
      const { data, error } = await supabase
        .from('assessment_templates')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) {
        console.error("Templates fetch error:", error);
      } else {
        setTemplates(data || []);
      }
    };
    fetchTemplates();
  }, []);

  const handleAddQuestion = () => {
    const newQuestion: AssessmentQuestion = {
      id: Date.now().toString(),
      text: '',
      options: ['Yes', 'No', 'Partially']
    };
    setFormData({
      ...formData,
      questions: [...(formData.questions || []), newQuestion]
    });
  };

  const handleRemoveQuestion = (id: string) => {
    setFormData({
      ...formData,
      questions: formData.questions?.filter(q => q.id !== id)
    });
  };

  const handleQuestionChange = (id: string, text: string) => {
    setFormData({
      ...formData,
      questions: formData.questions?.map(q => q.id === id ? { ...q, text } : q)
    });
  };

  const handleAddOption = (questionId: string) => {
    setFormData({
      ...formData,
      questions: formData.questions?.map(q => 
        q.id === questionId ? { ...q, options: [...q.options, ''] } : q
      )
    });
  };

  const handleOptionChange = (questionId: string, optionIndex: number, value: string) => {
    setFormData({
      ...formData,
      questions: formData.questions?.map(q => 
        q.id === questionId ? { 
          ...q, 
          options: q.options.map((opt, i) => i === optionIndex ? value : opt) 
        } : q
      )
    });
  };

  const handleRemoveOption = (questionId: string, optionIndex: number) => {
    setFormData({
      ...formData,
      questions: formData.questions?.map(q => 
        q.id === questionId ? { 
          ...q, 
          options: q.options.filter((_, i) => i !== optionIndex) 
        } : q
      )
    });
  };

  const handleSave = async () => {
    if (!formData.title || !formData.questions?.length) {
      toast.error('Please provide a title and at least one question');
      return;
    }

    try {
      if (isEditing) {
        const { error } = await supabase.from('assessment_templates').update({
          title: formData.title,
          description: formData.description,
          questions: formData.questions,
        }).eq('id', isEditing);
        if (error) throw error;
        toast.success('Template updated');
      } else {
        const { error } = await supabase.from('assessment_templates').insert({
          title: formData.title,
          description: formData.description,
          questions: formData.questions,
          created_at: new Date().toISOString()
        });
        if (error) throw error;
        toast.success('Template created');
      }
      setIsCreateOpen(false);
      setIsEditing(null);
      setFormData({ title: '', description: '', questions: [] });
      
      // Refresh
      const { data } = await supabase.from('assessment_templates').select('*').order('created_at', { ascending: false });
      setTemplates(data || []);
    } catch (error) {
      console.error('Error saving template:', error);
      toast.error('Failed to save template');
    }
  };

  const handleEdit = (template: AssessmentTemplate) => {
    setFormData(template);
    setIsEditing(template.id);
    setIsCreateOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this template?')) return;
    try {
      const { error } = await supabase.from('assessment_templates').delete().eq('id', id);
      if (error) throw error;
      toast.success('Template deleted');
      setTemplates(templates.filter(t => t.id !== id));
    } catch (error) {
      toast.error('Failed to delete template');
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div className="space-y-1">
          <h2 className="text-2xl font-serif">Assessment Templates</h2>
          <p className="text-sm text-muted-foreground">Manage global assessment structures for your clients.</p>
        </div>
        <Button 
          onClick={() => {
            setFormData({ title: '', description: '', questions: [] });
            setIsEditing(null);
            setIsCreateOpen(true);
          }}
          className="bg-[#1a1a1a] text-white rounded-full gap-2"
        >
          <Plus size={16} />
          Create Template
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {templates.map((template) => (
          <Card key={template.id} className="border-[#e5e5e5] shadow-sm hover:shadow-md transition-all group">
            <CardHeader>
              <div className="flex justify-between items-start mb-2">
                <div className="p-2 bg-[#f5f5f5] rounded-lg text-[#1a1a1a]">
                  <Settings2 size={20} />
                </div>
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button variant="ghost" size="icon" onClick={() => handleEdit(template)}>
                    <Edit2 size={14} />
                  </Button>
                  <Button variant="ghost" size="icon" className="text-destructive" onClick={() => handleDelete(template.id)}>
                    <Trash2 size={14} />
                  </Button>
                </div>
              </div>
              <CardTitle className="font-serif text-xl">{template.title}</CardTitle>
              <CardDescription className="line-clamp-2">{template.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>{template.questions.length} Questions</span>
                <span>Created {safeFormatDate(template.created_at, 'MMM d, yyyy')}</span>
              </div>
            </CardContent>
          </Card>
        ))}
        {templates.length === 0 && (
          <div className="col-span-full p-20 text-center border border-dashed border-[#e5e5e5] rounded-2xl text-muted-foreground font-light italic">
            No assessment templates created yet.
          </div>
        )}
      </div>

      <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto font-sans">
          <DialogHeader>
            <DialogTitle className="font-serif text-2xl">
              {isEditing ? 'Edit Template' : 'Create New Template'}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6 py-4">
            <div className="space-y-2">
              <label className="text-xs uppercase tracking-widest font-semibold">Template Title</label>
              <Input 
                placeholder="e.g. Lifestyle Audit" 
                value={formData.title}
                onChange={e => setFormData({...formData, title: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs uppercase tracking-widest font-semibold">Description</label>
              <Textarea 
                placeholder="Briefly describe the purpose of this assessment..." 
                value={formData.description}
                onChange={e => setFormData({...formData, description: e.target.value})}
              />
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-xs uppercase tracking-widest font-semibold">Questions</label>
                <Button variant="outline" size="sm" onClick={handleAddQuestion} className="rounded-full gap-2">
                  <Plus size={14} /> Add Question
                </Button>
              </div>

              <div className="space-y-4">
                {formData.questions?.map((q, qIdx) => (
                  <div key={q.id} className="p-4 border rounded-xl bg-slate-50/50 space-y-4">
                    <div className="flex gap-4">
                      <div className="flex-1 space-y-2">
                        <label className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Question {qIdx + 1}</label>
                        <Input 
                          placeholder="Enter question text..." 
                          value={q.text}
                          onChange={e => handleQuestionChange(q.id, e.target.value)}
                        />
                      </div>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="mt-6 text-destructive"
                        onClick={() => handleRemoveQuestion(q.id)}
                      >
                        <Trash2 size={16} />
                      </Button>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Answer Options</label>
                        <Button variant="ghost" size="sm" onClick={() => handleAddOption(q.id)} className="h-6 text-[10px] uppercase tracking-widest">
                          <Plus size={10} className="mr-1" /> Add Option
                        </Button>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        {q.options.map((opt, oIdx) => (
                          <div key={oIdx} className="flex gap-2">
                            <Input 
                              placeholder={`Option ${oIdx + 1}`}
                              value={opt}
                              onChange={e => handleOptionChange(q.id, oIdx, e.target.value)}
                              className="h-8 text-xs"
                            />
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8 text-destructive"
                              onClick={() => handleRemoveOption(q.id, oIdx)}
                            >
                              <X size={12} />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={handleSave} className="w-full bg-[#1a1a1a] text-white rounded-full h-12">
              {isEditing ? 'Update Template' : 'Save Template'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
