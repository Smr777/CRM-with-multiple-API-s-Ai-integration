import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function analyzeFeedback(responses: string[], questions: string[]) {
  const prompt = `
    Analyze the following client feedback responses for a premium consulting firm.
    
    Questions:
    ${questions.map((q, i) => `${i + 1}. ${q}`).join('\n')}
    
    Responses:
    ${responses.map((r, i) => `${i + 1}. ${r}`).join('\n')}
    
    Provide a structured analysis including:
    1. Overall Sentiment (Positive, Neutral, Negative)
    2. Key Patterns (Recurring themes or issues)
    3. Improvement Suggestions (Actionable advice for the firm)
    4. Hidden Insights (Subtle cues or underlying needs)
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            sentiment: { type: Type.STRING },
            patterns: { type: Type.ARRAY, items: { type: Type.STRING } },
            suggestions: { type: Type.ARRAY, items: { type: Type.STRING } },
            insights: { type: Type.STRING }
          },
          required: ["sentiment", "patterns", "suggestions", "insights"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("AI Analysis Error:", error);
    return null;
  }
}
