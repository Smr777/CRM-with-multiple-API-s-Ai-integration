import { supabase } from '../lib/supabase';

export interface UploadMetadata {
  user_id: string;
  type: string;
  context_id?: string;
  [key: string]: any;
}

export const uploadFile = async (
  file: File,
  bucket: string,
  path: string,
  metadata: UploadMetadata,
  onProgress?: (progress: number) => void
): Promise<string> => {
  const fileName = `${Date.now()}-${file.name}`;
  const filePath = `${path}/${fileName}`;

  // Supabase JS SDK doesn't have a built-in progress listener for simple uploads,
  // but we can simulate it or just handle the upload.
  // For larger files, TUS or other methods would be better.
  
  const { data, error } = await supabase.storage
    .from(bucket)
    .upload(filePath, file, {
      cacheControl: '3600',
      upsert: false
    });

  if (error) {
    console.error('Upload failed:', error);
    throw error;
  }

  const { data: { publicUrl } } = supabase.storage
    .from(bucket)
    .getPublicUrl(filePath);

  // Save to DB
  const { error: dbError } = await supabase.from('file_uploads').insert({
    ...metadata,
    file_name: file.name,
    file_type: file.type,
    storage_path: filePath,
    download_url: publicUrl,
    created_at: new Date().toISOString()
  });

  if (dbError) {
    console.error('Error saving upload metadata:', dbError);
    // We don't throw here to avoid failing the upload if just metadata fails,
    // but in a real app you might want to.
  }

  if (onProgress) onProgress(100);
  return publicUrl;
};
