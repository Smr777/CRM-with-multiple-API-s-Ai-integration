import { useEffect, useState } from 'react';
import { useAuth } from '../lib/AuthContext';
import { useParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Contract as ContractType } from '../types';
import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { FileText, PenTool, CheckCircle2, Calendar, Plus, Trash2 } from 'lucide-react';
import { safeFormatDate } from '../lib/date-utils';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export default function Contract() {
  const { profile } = useAuth();
  const { contractId } = useParams();
  const [contracts, setContracts] = useState<ContractType[]>([]);
  const [signature, setSignature] = useState('');
  const [signing, setSigning] = useState(false);
  const [newSession, setNewSession] = useState({ dateTime: '', duration: '' });

  useEffect(() => {
    if (!profile) return;
    
    const fetchContracts = async () => {
      let query = supabase.from('contracts').select('*');
      
      if (contractId) {
        query = query.eq('id', contractId);
      } else if (profile.role !== 'admin') {
        query = query.eq('client_id', profile.id);
      }
      
      const { data, error } = await query;
      
      if (error) {
        console.error("Contracts fetch error:", error);
      } else {
        setContracts(data || []);
      }
    };

    fetchContracts();
  }, [profile, contractId]);

  const handleSign = async (contractId: string) => {
    if (!signature) {
      toast.error('Please enter your full name as signature');
      return;
    }
    setSigning(true);
    try {
      const { error } = await supabase.from('contracts').update({
        signature,
        signed_at: new Date().toISOString(),
        status: 'signed'
      }).eq('id', contractId);
      
      if (error) throw error;
      
      toast.success('Contract signed successfully');
      // Refresh
      const { data } = await supabase.from('contracts').select('*').eq('id', contractId);
      if (data) setContracts(data);
    } catch (error) {
      toast.error('Failed to sign contract');
    } finally {
      setSigning(false);
    }
  };

  const handleAddSession = async (contractId: string) => {
    if (!newSession.dateTime || !newSession.duration) {
      toast.error('Please fill in date and duration');
      return;
    }
    try {
      // In Supabase we use columns instead of arrayUnion
      const { error } = await supabase.from('contracts').update({
        session_date_time: newSession.dateTime,
        session_duration: newSession.duration
      }).eq('id', contractId);
      
      if (error) throw error;
      
      setNewSession({ dateTime: '', duration: '' });
      toast.success('Session scheduled');
      
      // Refresh
      const { data } = await supabase.from('contracts').select('*').eq('id', contractId);
      if (data) setContracts(data);
    } catch (error) {
      toast.error('Failed to add session');
    }
  };

  const handleRemoveSession = async (contractId: string) => {
    try {
      const { error } = await supabase.from('contracts').update({
        session_date_time: null,
        session_duration: null
      }).eq('id', contractId);
      
      if (error) throw error;
      
      toast.success('Session removed');
      // Refresh
      const { data } = await supabase.from('contracts').select('*').eq('id', contractId);
      if (data) setContracts(data);
    } catch (error) {
      toast.error('Failed to remove session');
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-12">
      <header className="space-y-2 text-center">
        <h1 className="text-4xl font-serif">Digital Agreement</h1>
        <p className="text-muted-foreground font-light tracking-wide">Establish our professional consulting partnership.</p>
        <p className="text-xs text-amber-700 font-bold uppercase tracking-[0.1em] mt-6 max-w-2xl mx-auto leading-relaxed">
          Please review the contract terms carefully. By signing and submitting this agreement prior to making the payment, you acknowledge and accept all stated terms, including our cancellation policy regarding non-refundable sessions.
        </p>
      </header>

      {contracts.length > 0 ? (
        <div className="space-y-8">
          {contracts.map(contract => (
            <motion.div
              key={contract.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-8"
            >
              <Card className="border-[#e5e5e5] shadow-lg overflow-hidden">
                <CardHeader className="bg-[#f9f9f9] border-b border-[#e5e5e5] flex flex-row items-center justify-between">
                  <div className="space-y-1">
                    <CardTitle className="font-serif text-2xl">Consulting Service Agreement</CardTitle>
                    <div className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground uppercase tracking-widest">
                      <span className="flex items-center gap-1"><FileText size={12} /> Ref: {contract.id.slice(0, 8)}</span>
                    </div>
                  </div>
                  <Badge className={cn(
                    "rounded-full px-4 py-1 text-[10px] uppercase tracking-widest",
                    contract.status === 'signed' ? "bg-green-50 text-green-700 border-green-100" : "bg-amber-50 text-amber-700 border-amber-100"
                  )}>
                    {contract.status}
                  </Badge>
                </CardHeader>
                <CardContent className="p-12 space-y-8">
                  
                  <div className="prose prose-slate max-w-none font-bold leading-relaxed text-[#1a1a1a] space-y-6 text-xl whitespace-pre-wrap break-words">
                    {contract.content ? contract.content.split('\n').map((para, i) => (
                      <p key={i} className="break-words">{para}</p>
                    )) : <p>No contract content available.</p>}
                  </div>

                  {/* Sessions Section */}
                  <div className="space-y-4 pt-8 border-t border-[#e5e5e5]">
                    <h3 className="text-sm uppercase tracking-widest font-semibold text-muted-foreground">Scheduled Sessions</h3>
                    <div className="grid gap-2">
                      {contract.session_date_time && (
                        <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border border-slate-100">
                          <div className="flex items-center gap-4">
                            <Calendar size={16} className="text-muted-foreground" />
                            <span className="text-sm font-medium">
                              {safeFormatDate(contract.session_date_time, 'EEEE, MMMM d, yyyy', 'Date to be scheduled')}
                              {contract.session_duration && ` (${contract.session_duration})`}
                            </span>
                          </div>
                          {profile?.role === 'admin' && (
                            <Button variant="ghost" size="sm" className="text-destructive" onClick={() => handleRemoveSession(contract.id)}>
                              <Trash2 size={14} />
                            </Button>
                          )}
                        </div>
                      )}
                    </div>
                    {profile?.role === 'admin' && !contract.session_date_time && (
                      <div className="flex gap-2 p-4 bg-white border-slate-200 rounded-lg">
                        <Input type="datetime-local" value={newSession.dateTime} onChange={e => setNewSession({...newSession, dateTime: e.target.value})} />
                        <Input placeholder="Duration (e.g. 60 min)" value={newSession.duration} onChange={e => setNewSession({...newSession, duration: e.target.value})} />
                        <Button onClick={() => handleAddSession(contract.id)} className="gap-2">
                          <Plus size={16} /> Schedule
                        </Button>
                      </div>
                    )}
                  </div>

                  <div className="mt-16 pt-12 border-t border-[#e5e5e5] grid grid-cols-1 md:grid-cols-2 gap-12">
                    <div className="space-y-4">
                      <h3 className="text-sm uppercase tracking-widest font-semibold text-muted-foreground">Brand Signature</h3>
                      <div className="h-20 flex items-end border-b border-[#e5e5e5] pb-2">
                        <div className="flex flex-col">
                          <span className="font-serif text-3xl italic opacity-50">Anamika Mishra</span>
                          <span className="text-xs text-muted-foreground mt-1">(Anamika's Rationale Tranquillity)</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      {contract.status !== 'signed' && profile?.role === 'client' && (
                        <p className="text-sm text-amber-800 font-bold uppercase tracking-[0.05em] leading-relaxed mb-6 p-4 bg-amber-50 rounded-lg border border-amber-200">
                          By signing and submitting this contract, you formally acknowledge that you have read, understood, and agree to abide by all terms and conditions set forth in this agreement.
                        </p>
                      )}
                      <h3 className="text-sm uppercase tracking-widest font-semibold text-muted-foreground">Client Signature</h3>
                      {contract.status === 'signed' ? (
                        <div className="space-y-2">
                          <div className="h-20 flex items-end border-b border-[#e5e5e5] pb-2">
                            <span className="font-serif text-3xl italic">{contract.signature}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <p className="text-[10px] text-muted-foreground">
                              Signed on {safeFormatDate(contract.signed_at, 'EEEE, MMMM d, yyyy \'at\' h:mm a')}
                            </p>
                            <CheckCircle2 size={16} className="text-green-600" />
                          </div>
                        </div>
                      ) : (
                        profile?.role === 'client' && (
                          <div className="space-y-4">
                            <div className="relative">
                              <PenTool className="absolute left-0 bottom-2 text-muted-foreground" size={20} />
                              <Input 
                                placeholder="Type your full name to sign" 
                                className="pl-8 border-t-0 border-x-0 border-b border-[#e5e5e5] rounded-none focus-visible:ring-0 focus-visible:border-[#1a1a1a] h-12 font-serif text-2xl italic"
                                value={signature}
                                onChange={(e) => setSignature(e.target.value)}
                              />
                            </div>
                            <Button 
                              onClick={() => handleSign(contract.id)}
                              disabled={signing}
                              className="w-full bg-[#1a1a1a] text-white rounded-full h-12 hover:bg-[#333] transition-all"
                            >
                              {signing ? 'Processing...' : 'Sign Agreement Digitally'}
                            </Button>
                          </div>
                        )
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="p-20 text-center border border-dashed border-[#e5e5e5] rounded-2xl text-muted-foreground font-light italic">
          No active contracts found.
        </div>
      )}
    </div>
  );
}
