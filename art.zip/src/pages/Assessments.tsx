import { useEffect, useState } from 'react';
import { useAuth } from '../lib/AuthContext';
import { supabase } from '../lib/supabase';
import { ClientAssessment, ClientAssessmentQuestion } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
  ClipboardCheck, 
  ChevronRight, 
  ChevronLeft, 
  CheckCircle2, 
  FileDown,
  Clock,
  AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';
import { safeFormatDate } from '../lib/date-utils';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

export default function Assessments() {
  const { profile } = useAuth();
  const [assessments, setAssessments] = useState<ClientAssessment[]>([]);
  const [activeAssessment, setActiveAssessment] = useState<ClientAssessment | null>(null);
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!profile) return;
    const fetchAssessments = async () => {
      const { data, error } = await supabase
        .from('client_assessments')
        .select('*')
        .eq('client_id', profile.id);
      
      if (error) {
        console.error("Assessments fetch error:", error);
      } else {
        setAssessments(data || []);
      }
    };
    fetchAssessments();
  }, [profile]);

  const startAssessment = (assessment: ClientAssessment) => {
    setActiveAssessment(assessment);
    setCurrentQuestionIdx(0);
  };

  const handleAnswer = (option: string) => {
    if (!activeAssessment) return;
    
    const newQuestions = [...activeAssessment.questions];
    newQuestions[currentQuestionIdx] = {
      ...newQuestions[currentQuestionIdx],
      answer: option
    };

    setActiveAssessment({
      ...activeAssessment,
      questions: newQuestions
    });
    
    // Auto-advance if not last question
    if (currentQuestionIdx < activeAssessment.questions.length - 1) {
      setTimeout(() => setCurrentQuestionIdx(currentQuestionIdx + 1), 300);
    }
  };

  const submitAssessment = async () => {
    if (!profile || !activeAssessment) return;
    setSubmitting(true);
    try {
      const { error } = await supabase.from('client_assessments').update({
        questions: activeAssessment.questions,
        status: 'completed',
        submitted_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }).eq('id', activeAssessment.id);
      
      if (error) throw error;
      
      toast.success('Assessment submitted successfully');
      setActiveAssessment(null);
      
      // Refresh list
      const { data } = await supabase.from('client_assessments').select('*').eq('client_id', profile.id);
      setAssessments(data || []);
    } catch (error) {
      toast.error('Failed to submit assessment');
    } finally {
      setSubmitting(false);
    }
  };

  const saveProgress = async () => {
    if (!profile || !activeAssessment) return;
    try {
      const { error } = await supabase.from('client_assessments').update({
        questions: activeAssessment.questions,
        updated_at: new Date().toISOString()
      }).eq('id', activeAssessment.id);
      
      if (error) throw error;
      
      toast.success('Progress saved');
    } catch (error) {
      toast.error('Failed to save progress');
    }
  };

  if (activeAssessment) {
    const currentQuestion = activeAssessment.questions[currentQuestionIdx];
    const progress = ((currentQuestionIdx + 1) / activeAssessment.questions.length) * 100;
    const isLastQuestion = currentQuestionIdx === activeAssessment.questions.length - 1;
    const hasAnsweredCurrent = !!currentQuestion.answer;

    return (
      <div className="max-w-3xl mx-auto py-12 space-y-8">
        <div className="flex items-center justify-between">
          <Button variant="ghost" onClick={() => setActiveAssessment(null)} className="rounded-full gap-2">
            <ChevronLeft size={18} />
            Back to List
          </Button>
          <Button variant="outline" onClick={saveProgress} className="rounded-full text-xs uppercase tracking-widest">
            Save Progress
          </Button>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between text-sm uppercase tracking-widest font-medium text-muted-foreground">
            <span>{activeAssessment.title}</span>
            <span>Question {currentQuestionIdx + 1} of {activeAssessment.questions.length}</span>
          </div>
          <Progress value={progress} className="h-1 bg-[#e5e5e5]" />
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentQuestionIdx}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-8"
          >
            <h2 className="text-3xl font-serif leading-tight">
              {currentQuestion.text}
            </h2>

            <div className="grid grid-cols-1 gap-4">
              {currentQuestion.options.map((option, idx) => (
                <button
                  key={idx}
                  onClick={() => handleAnswer(option)}
                  className={cn(
                    "p-6 text-left border rounded-xl transition-all duration-200 group",
                    currentQuestion.answer === option 
                      ? "border-[#1a1a1a] bg-[#1a1a1a] text-white" 
                      : "border-[#e5e5e5] hover:border-[#1a1a1a] bg-white"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-light">{option}</span>
                    <div className={cn(
                      "w-6 h-6 rounded-full border flex items-center justify-center transition-colors",
                      currentQuestion.answer === option ? "border-white" : "border-[#e5e5e5] group-hover:border-[#1a1a1a]"
                    )}>
                      {currentQuestion.answer === option && <div className="w-3 h-3 rounded-full bg-white" />}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </motion.div>
        </AnimatePresence>

        <div className="flex justify-between pt-8">
          <Button
            variant="ghost"
            onClick={() => setCurrentQuestionIdx(Math.max(0, currentQuestionIdx - 1))}
            disabled={currentQuestionIdx === 0}
            className="rounded-full gap-2"
          >
            <ChevronLeft size={18} />
            Previous
          </Button>
          
          {isLastQuestion ? (
            <Button
              onClick={submitAssessment}
              disabled={!hasAnsweredCurrent || submitting}
              className="bg-[#1a1a1a] text-white rounded-full px-8"
            >
              {submitting ? 'Submitting...' : 'Complete Assessment'}
            </Button>
          ) : (
            <Button
              onClick={() => setCurrentQuestionIdx(currentQuestionIdx + 1)}
              disabled={!hasAnsweredCurrent}
              className="rounded-full gap-2"
            >
              Next
              <ChevronRight size={18} />
            </Button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-12">
      <header className="space-y-2">
        <h1 className="text-4xl font-serif">Assessments</h1>
        <p className="text-muted-foreground font-light tracking-wide">Deep dives into your personal and professional evolution.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {assessments.map((assessment) => {
          const isCompleted = assessment.status === 'completed';

          return (
            <Card key={assessment.id} className="border-[#e5e5e5] shadow-sm hover:shadow-md transition-all group">
              <CardHeader>
                <div className="flex justify-between items-start mb-2">
                  <div className="p-2 bg-[#f5f5f5] rounded-lg text-[#1a1a1a]">
                    <ClipboardCheck size={20} />
                  </div>
                  {isCompleted && (
                    <Badge variant="secondary" className="bg-green-50 text-green-700 border-green-100 rounded-full gap-1">
                      <CheckCircle2 size={12} />
                      Completed
                    </Badge>
                  )}
                </div>
                <CardTitle className="font-serif text-xl">{assessment.title}</CardTitle>
                <CardDescription className="font-light leading-relaxed line-clamp-2">{assessment.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{assessment.questions.length} Questions</span>
                  <div className="flex items-center gap-1">
                    <Clock size={12} />
                    {safeFormatDate(assessment.updated_at, 'MMM d')}
                  </div>
                </div>

                {isCompleted ? (
                  <div className="space-y-4">
                    {assessment.submitted_at && (
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <CheckCircle2 size={14} className="text-green-600" />
                        Submitted on {safeFormatDate(assessment.submitted_at, 'MMM d, yyyy')}
                      </div>
                    )}
                    {assessment.report_url ? (
                      <Button 
                        onClick={() => window.open(assessment.report_url, '_blank')}
                        className="w-full bg-[#1a1a1a] text-white rounded-full gap-2"
                      >
                        <FileDown size={16} />
                        Download Report
                      </Button>
                    ) : (
                      <div className="p-3 bg-[#f9f9f9] rounded-lg text-[10px] text-center uppercase tracking-widest text-muted-foreground font-medium">
                        Report Pending Admin Review
                      </div>
                    )}
                  </div>
                ) : (
                  <Button 
                    onClick={() => startAssessment(assessment)}
                    className="w-full bg-white border border-[#1a1a1a] text-[#1a1a1a] hover:bg-[#1a1a1a] hover:text-white rounded-full transition-all"
                  >
                    {assessment.questions.some(q => q.answer) ? 'Continue Assessment' : 'Start Assessment'}
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}
        {assessments.length === 0 && (
          <div className="col-span-full p-20 text-center border border-dashed border-[#e5e5e5] rounded-2xl text-muted-foreground font-light italic">
            No assessments assigned to you yet. Your coach will assign them soon.
          </div>
        )}
      </div>
    </div>
  );
}
