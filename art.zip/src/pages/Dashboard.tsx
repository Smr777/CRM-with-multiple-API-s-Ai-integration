import React, { useEffect, useState } from 'react';
import { useAuth } from '../lib/AuthContext';
import { supabase } from '../lib/supabase';
import { QUOTES } from '../constants/quotes';
import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ClipboardCheck, MessageSquare, CreditCard, FileText, Bell, Info, Quote, Download } from 'lucide-react';
import { Notice } from '../types';
import { safeFormatDate } from '../lib/date-utils';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

export default function Dashboard() {
  const { profile } = useAuth();
  const [notices, setNotices] = useState<Notice[]>([]);
  const [quote, setQuote] = useState('');

  useEffect(() => {
    // Quote of the day logic
    const today = new Date();
    const startOfYear = new Date(today.getUTCFullYear(), 0, 0);
    const diff = (today.getTime() - startOfYear.getTime()) + ((startOfYear.getTimezoneOffset() - today.getTimezoneOffset()) * 60 * 1000);
    const dayOfYear = Math.floor(diff / (1000 * 60 * 60 * 24));
    setQuote(QUOTES[dayOfYear % QUOTES.length]);

    if (!profile) return;

    // Fetch notices
    const fetchNotices = async () => {
      try {
        const { data, error } = await supabase
          .from('notices')
          .select('*')
          .in('target', ['all', profile.client_type || 'individual'])
          .order('created_at', { ascending: false });
        
        if (error) throw error;
        setNotices(data || []);
      } catch (error: any) {
        console.error("Notices fetch error:", error);
        toast.error(`Could not load announcements: ${error.message || "Network error"}`);
      }
    };

    // Reconcile pending invites for the current user
    const reconcileInvites = async () => {
      if (!profile.email) return;
      try {
        const { data: invites, error: fetchError } = await supabase
          .from('invites')
          .select('id')
          .eq('email', profile.email.toLowerCase())
          .eq('status', 'pending');
        
        if (fetchError) throw fetchError;
        
        if (invites && invites.length > 0) {
          const ids = invites.map(i => i.id);
          const { error: updateError } = await supabase
            .from('invites')
            .update({
              status: 'accepted',
              accepted_at: new Date().toISOString()
            })
            .in('id', ids);
          
          if (updateError) throw updateError;
          console.log('Invites reconciled');
        }
      } catch (error) {
        console.error('Error reconciling invites:', error);
      }
    };

    fetchNotices();
    reconcileInvites();
  }, [profile]);

  return (
    <div className="max-w-6xl mx-auto space-y-12">
      <header className="space-y-2">
        <motion.h1 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-4xl font-serif"
        >
          Welcome, {profile?.display_name}
        </motion.h1>
        <p className="text-muted-foreground font-light tracking-wide">
          {safeFormatDate(new Date(), 'EEEE, MMMM do yyyy')}
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Quote of the Day */}
        <Card className="md:col-span-2 bg-white border-[#e5e5e5] shadow-sm overflow-hidden group">
          <CardHeader className="pb-2">
            <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.2em] text-muted-foreground font-semibold">
              <Quote size={12} />
              Reflections
            </div>
          </CardHeader>
          <CardContent className="pt-4 pb-12 px-10">
            <blockquote className="text-3xl font-serif italic leading-snug text-[#1a1a1a]">
              "{quote}"
            </blockquote>
          </CardContent>
          <div className="h-1 w-full bg-gradient-to-r from-transparent via-[#1a1a1a] to-transparent opacity-10 group-hover:opacity-30 transition-opacity" />
        </Card>

        {/* Instructions Card */}
        <div className="space-y-4">
          <Card className="bg-[#1a1a1a] text-white border-none shadow-xl">
            <CardHeader>
              <CardTitle className="text-xl font-serif flex items-center gap-2">
                <Info size={18} />
                Portal Guide
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm font-light leading-relaxed text-gray-300">
              {profile?.welcome_instructions || "Welcome to your private consulting portal. Here you can track your progress, complete assessments, and manage your billing securely."}
            </CardContent>
          </Card>

          {profile?.welcome_packet_url && (
            <Card className="bg-white border-[#e5e5e5] shadow-sm border-l-4 border-l-blue-600">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-serif flex items-center gap-2">
                  <FileText size={16} className="text-blue-600" />
                  Welcome Packet
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-xs text-muted-foreground font-light">Your personalized onboarding document is ready for review.</p>
                <Button 
                  variant="outline" 
                  className="w-full rounded-full gap-2 text-xs h-8"
                  onClick={() => window.open(profile.welcome_packet_url, '_blank')}
                >
                  <Download size={14} />
                  View Welcome Packet
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Notice Board */}
        <section className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-serif">Notice Board</h2>
            <Bell size={20} className="text-muted-foreground" />
          </div>
          <div className="space-y-4">
            {notices.length > 0 ? notices.map((notice) => (
              <motion.div 
                key={notice.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-6 bg-white border border-[#e5e5e5] rounded-xl shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-medium text-lg">{notice.title}</h3>
                  <span className="text-[10px] text-muted-foreground uppercase tracking-wider">
                    {safeFormatDate(notice.created_at, 'MMM d')}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground font-light leading-relaxed">
                  {notice.content}
                </p>
              </motion.div>
            )) : (
              <div className="p-12 text-center border border-dashed border-[#e5e5e5] rounded-xl text-muted-foreground font-light italic">
                No new announcements at this time.
              </div>
            )}
          </div>
        </section>

        {/* Quick Links / Status */}
        <section className="space-y-6">
          <h2 className="text-2xl font-serif">Your Journey</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <QuickLinkCard 
              title="Assessments" 
              desc="6 modules available" 
              icon={<ClipboardCheck size={24} />} 
              href="/assessments"
            />
            <QuickLinkCard 
              title="Feedback" 
              desc="Share your insights" 
              icon={<MessageSquare size={24} />} 
              href="/feedback"
            />
            <QuickLinkCard 
              title="Billing" 
              desc="View invoices" 
              icon={<CreditCard size={24} />} 
              href="/billing"
            />
            <QuickLinkCard 
              title="Contract" 
              desc="Digital agreement" 
              icon={<FileText size={24} />} 
              href="/contract"
            />
          </div>
        </section>
      </div>
    </div>
  );
}

function QuickLinkCard({ title, desc, icon, href }: { title: string, desc: string, icon: React.ReactNode, href: string }) {
  return (
    <a 
      href={href}
      className="p-6 bg-white border border-[#e5e5e5] rounded-xl shadow-sm hover:border-[#1a1a1a] transition-all group"
    >
      <div className="text-muted-foreground group-hover:text-[#1a1a1a] transition-colors mb-4">
        {icon}
      </div>
      <h3 className="font-medium">{title}</h3>
      <p className="text-xs text-muted-foreground font-light mt-1">{desc}</p>
    </a>
  );
}
