import { useEffect, useState } from 'react';
import { useAuth } from '../lib/AuthContext';
import { supabase } from '../lib/supabase';
import { FeedbackForm, FeedbackResponse } from '../types';
import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { MessageSquare, Send, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';

export default function Feedback() {
  const { profile } = useAuth();
  const [forms, setForms] = useState<FeedbackForm[]>([]);
  const [responses, setResponses] = useState<FeedbackResponse[]>([]);
  const [activeForm, setActiveForm] = useState<FeedbackForm | null>(null);
  const [currentResponses, setCurrentResponses] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!profile) return;
    
    const fetchData = async () => {
      // Fetch active forms
      const { data: formsData } = await supabase
        .from('feedback_forms')
        .select('*')
        .eq('active', true);
      setForms(formsData || []);

      // Fetch user responses
      const { data: responsesData } = await supabase
        .from('feedback_responses')
        .select('*')
        .eq('client_id', profile.id);
      setResponses(responsesData || []);
    };

    fetchData();
  }, [profile]);

  const handleSubmit = async () => {
    if (!profile || !activeForm) return;
    setSubmitting(true);
    try {
      const { error } = await supabase.from('feedback_responses').insert({
        form_id: activeForm.id,
        client_id: profile.id,
        responses: currentResponses,
        submitted_at: new Date().toISOString(),
      });
      if (error) throw error;
      
      toast.success('Thank you for your feedback');
      setActiveForm(null);
      setCurrentResponses([]);
      
      // Refresh responses
      const { data } = await supabase.from('feedback_responses').select('*').eq('client_id', profile.id);
      setResponses(data || []);
    } catch (error) {
      toast.error('Failed to submit feedback');
    } finally {
      setSubmitting(false);
    }
  };

  if (activeForm) {
    return (
      <div className="max-w-3xl mx-auto py-12 space-y-8">
        <header className="space-y-2">
          <Button variant="ghost" onClick={() => setActiveForm(null)} className="mb-4">Back</Button>
          <h1 className="text-4xl font-serif">{activeForm.title}</h1>
          <p className="text-muted-foreground font-light">Your insights help us refine our partnership.</p>
        </header>

        <div className="space-y-8">
          {activeForm.questions.map((q, i) => (
            <div key={i} className="space-y-4">
              <label className="text-lg font-medium">{q}</label>
              <Textarea 
                placeholder="Share your thoughts..."
                className="min-h-[120px] bg-white border-[#e5e5e5] rounded-xl focus-visible:ring-[#1a1a1a]"
                value={currentResponses[i] || ''}
                onChange={(e) => {
                  const newRes = [...currentResponses];
                  newRes[i] = e.target.value;
                  setCurrentResponses(newRes);
                }}
              />
            </div>
          ))}

          <Button 
            onClick={handleSubmit} 
            disabled={submitting || currentResponses.length < activeForm.questions.length}
            className="w-full bg-[#1a1a1a] text-white rounded-full h-12 gap-2"
          >
            <Send size={18} />
            {submitting ? 'Submitting...' : 'Submit Feedback'}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-12">
      <header className="space-y-2">
        <h1 className="text-4xl font-serif">Feedback</h1>
        <p className="text-muted-foreground font-light tracking-wide">Continuous improvement through open dialogue.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {forms.map((form) => {
          const hasResponded = responses.some(r => r.form_id === form.id);
          return (
            <Card key={form.id} className="border-[#e5e5e5] shadow-sm hover:shadow-md transition-all">
              <CardHeader>
                <div className="p-2 w-fit bg-[#f5f5f5] rounded-lg text-[#1a1a1a] mb-2">
                  <MessageSquare size={20} />
                </div>
                <CardTitle className="font-serif text-xl">{form.title}</CardTitle>
                <CardDescription>{form.questions.length} Questions</CardDescription>
              </CardHeader>
              <CardContent>
                {hasResponded ? (
                  <div className="flex items-center gap-2 text-green-600 font-medium text-sm">
                    <CheckCircle2 size={16} />
                    Response Submitted
                  </div>
                ) : (
                  <Button 
                    onClick={() => {
                      setActiveForm(form);
                      setCurrentResponses(new Array(form.questions.length).fill(''));
                    }}
                    className="w-full bg-white border border-[#1a1a1a] text-[#1a1a1a] hover:bg-[#1a1a1a] hover:text-white rounded-full transition-all"
                  >
                    Provide Feedback
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
