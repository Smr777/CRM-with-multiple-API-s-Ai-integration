import React, { useEffect, useState, ChangeEvent, useRef } from 'react';
import { useAuth } from '../lib/AuthContext';
import { supabase } from '../lib/supabase';
import { Invoice } from '../types';
import { motion } from 'motion/react';
import jsPDF from 'jspdf';
import { cn } from '@/lib/utils';
import { FileUpload } from '../components/FileUpload';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { safeFormatDate } from '../lib/date-utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CreditCard, FileDown, Receipt, Upload, Eye, Trash2, FileText, Download, Sparkles } from 'lucide-react';
import { format, isValid } from 'date-fns';
import { toast } from 'sonner';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogTrigger
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';

export default function Billing() {
  const { profile } = useAuth();
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string | null>(null);
  const [proofUrl, setProofUrl] = useState('');
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (!profile) return;
    const fetchInvoices = async () => {
      const { data, error } = await supabase
        .from('invoices')
        .select('*')
        .eq('client_id', profile.id)
        .order('date', { ascending: false });
      
      if (error) {
        console.error("Invoices fetch error:", error);
      } else {
        setInvoices(data || []);
      }
    };
    fetchInvoices();
  }, [profile]);

  const totalBilled = invoices.reduce((acc, inv) => acc + (Number(inv.amount) || 0), 0);
  const totalPaid = invoices.filter(inv => inv.status === 'paid').reduce((acc, inv) => acc + (Number(inv.amount) || 0), 0);
  const totalPending = totalBilled - totalPaid;

  const handleUploadProof = async () => {
    if (!selectedInvoiceId || !proofUrl) return;
    try {
      const invoice = invoices.find(i => i.id === selectedInvoiceId);
      const newHistory = [...(invoice?.proof_history || []), proofUrl];
      
      const { error } = await supabase.from('invoices').update({
        proof_of_payment_url: proofUrl,
        proof_history: newHistory,
        status: 'verifying'
      }).eq('id', selectedInvoiceId);
      
      if (error) throw error;
      
      toast.success('Payment proof uploaded for verification');
      setIsUploadOpen(false);
      setProofUrl('');
      setSelectedInvoiceId(null);
      
      // Refresh invoices
      const { data } = await supabase.from('invoices').select('*').eq('client_id', profile!.id).order('date', { ascending: false });
      setInvoices(data || []);
    } catch (error) {
      toast.error('Failed to upload proof');
    }
  };

  const handleRemoveProof = async (invoiceId: string) => {
    try {
      const { error } = await supabase.from('invoices').update({
        proof_of_payment_url: null,
        status: 'unpaid'
      }).eq('id', invoiceId);
      
      if (error) throw error;
      
      toast.success('Proof removed. You can upload a new one.');
      // Refresh invoices
      const { data } = await supabase.from('invoices').select('*').eq('client_id', profile!.id).order('date', { ascending: false });
      setInvoices(data || []);
    } catch (error) {
      toast.error('Failed to remove proof');
    }
  };

  const handleFileUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!selectedInvoiceId) {
      toast.error('No invoice selected. Please select an invoice first.');
      return;
    }

    const isPdf = file.type === 'application/pdf' || file.type === 'application/x-pdf';
    const isImage = file.type.startsWith('image/');
    
    if (!isPdf && !isImage) {
      toast.error('Please upload a PDF or image file');
      return;
    }

    setUploading(true);
    try {
      const fileName = `${Date.now()}-${file.name}`;
      const filePath = `proofs/${profile?.id}/${fileName}`;
      
      const { data, error } = await supabase.storage
        .from('documents')
        .upload(filePath, file);

      if (error) throw error;

      const { data: { publicUrl } } = supabase.storage
        .from('documents')
        .getPublicUrl(filePath);
      
      const invoice = invoices.find(i => i.id === selectedInvoiceId);
      const newHistory = [...(invoice?.proof_history || []), publicUrl];

      const { error: updateError } = await supabase.from('invoices').update({
        proof_of_payment_url: publicUrl,
        proof_history: newHistory,
        status: 'verifying'
      }).eq('id', selectedInvoiceId);
      
      if (updateError) throw updateError;
      
      toast.success('Payment proof uploaded for verification');
      setIsUploadOpen(false);
      setSelectedInvoiceId(null);
      
      // Refresh invoices
      const { data: refreshData } = await supabase.from('invoices').select('*').eq('client_id', profile!.id).order('date', { ascending: false });
      setInvoices(refreshData || []);
    } catch (error) {
      console.error('Upload error:', error);
      toast.error(`Failed to upload file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setUploading(false);
    }
  };

  const handleDownload = async (url: string, filename: string) => {
    try {
      const proxyUrl = `/api/proxy-download?url=${encodeURIComponent(url)}&filename=${encodeURIComponent(filename)}`;
      const response = await fetch(proxyUrl);
      if (!response.ok) throw new Error('Download failed');
      
      const blob = await response.blob();
      const contentType = blob.type;

      if (contentType === 'application/pdf') {
        const blobUrl = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = blobUrl;
        link.download = filename.endsWith('.pdf') ? filename : `${filename}.pdf`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(blobUrl);
        return;
      }

      if (contentType.startsWith('image/')) {
        const img = new Image();
        const imageUrl = window.URL.createObjectURL(blob);
        
        img.onload = () => {
          const pdf = new jsPDF({
            orientation: img.width > img.height ? 'landscape' : 'portrait',
            unit: 'px',
            format: [img.width, img.height]
          });
          
          pdf.addImage(imageUrl, 'JPEG', 0, 0, img.width, img.height);
          pdf.save(filename.endsWith('.pdf') ? filename : `${filename}.pdf`);
          window.URL.revokeObjectURL(imageUrl);
        };
        
        img.onerror = () => {
          toast.error('Failed to process image for PDF conversion');
        };
        
        img.src = imageUrl;
        return;
      }

      const blobUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    } catch (error) {
      console.error('Download failed:', error);
      toast.error('Failed to download file. Opening in new tab instead.');
      window.open(url, '_blank');
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-12">
      <header className="space-y-2">
        <h1 className="text-4xl font-serif">Billing & Invoices</h1>
        <p className="text-muted-foreground font-light tracking-wide">Manage your financial commitments and view transaction history.</p>
        <p className="text-sm text-amber-600 font-medium uppercase tracking-wider mt-4">
          Pay the payment to get started and upload screenshot of payment proof.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <StatCard title="Total Billed" value={`$${totalBilled.toLocaleString()}`} icon={<Receipt size={20} />} />
        <StatCard title="Paid" value={`$${totalPaid.toLocaleString()}`} icon={<CreditCard size={20} />} className="text-green-600" />
        <StatCard title="Pending" value={`$${totalPending.toLocaleString()}`} icon={<Receipt size={20} />} className="text-amber-600" />
      </div>

      <Card className="border-[#e5e5e5] shadow-sm overflow-hidden">
        <CardHeader className="bg-[#f9f9f9] border-b border-[#e5e5e5]">
          <CardTitle className="font-serif text-xl">Invoice History</CardTitle>
        </CardHeader>
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead className="font-serif text-[#1a1a1a]">Date</TableHead>
              <TableHead className="font-serif text-[#1a1a1a]">Description</TableHead>
              <TableHead className="font-serif text-[#1a1a1a]">Amount</TableHead>
              <TableHead className="font-serif text-[#1a1a1a]">Status</TableHead>
              <TableHead className="text-right font-serif text-[#1a1a1a]">Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {invoices.length > 0 ? invoices.map((invoice) => (
              <TableRow key={invoice.id} className="hover:bg-[#fafafa] transition-colors">
                <TableCell className="text-muted-foreground font-light">
                  {safeFormatDate(invoice.date, 'MMM d, yyyy')}
                </TableCell>
                <TableCell className="font-medium">{invoice.description}</TableCell>
                <TableCell className="font-medium">${invoice.amount.toLocaleString()}</TableCell>
                <TableCell>
                  <Badge className={cn(
                    "rounded-full px-3 py-0.5 text-[10px] uppercase tracking-widest",
                    invoice.status === 'paid' ? "bg-green-50 text-green-700 border-green-100" : 
                    invoice.status === 'verifying' ? "bg-blue-50 text-blue-700 border-blue-100" :
                    "bg-amber-50 text-amber-700 border-amber-100"
                  )}>
                    {invoice.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-2">
                    {invoice.status === 'unpaid' && (
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="rounded-full gap-2"
                        onClick={() => {
                          setSelectedInvoiceId(invoice.id);
                          setIsUploadOpen(true);
                        }}
                      >
                        <Upload size={14} />
                        Upload Proof
                      </Button>
                    )}
                    <Button variant="ghost" size="sm" className="rounded-full gap-2 hover:bg-[#1a1a1a] hover:text-white transition-all">
                      <FileDown size={14} />
                      PDF
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            )) : (
              <TableRow>
                <TableCell colSpan={5} className="p-12 text-center text-muted-foreground font-light italic">
                  No invoices found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Card>

      <div className="py-6 border-t border-b border-[#e5e5e5] bg-[#fafafa] text-center">
        <p className="text-sm text-muted-foreground">Please upload screenshot of the payment successful with account details to complete the action and unlock the Full CRM</p>
      </div>

      <Card className="border-[#e5e5e5] shadow-sm">
        <CardHeader>
          <CardTitle className="font-serif text-xl flex items-center gap-2">
            <FileText size={18} />
            Payment Proofs
          </CardTitle>
          <CardDescription>
            View your uploaded payment proofs and history. 
            <span className="block mt-1 font-semibold text-amber-700">Once you upload and save the file is locked in and cannot be changed!</span>
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-6">
            <Button 
              onClick={() => {
                setSelectedInvoiceId(null);
                setIsUploadOpen(true);
              }}
              className="bg-[#1a1a1a] text-white rounded-full gap-2"
            >
              <Upload size={16} />
              Upload New Proof
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {invoices.filter(inv => inv.proof_of_payment_url || (inv.proof_history && inv.proof_history.length > 0)).map((inv) => (
              <div key={inv.id} className="p-4 border border-[#e5e5e5] rounded-xl space-y-4 bg-[#fafafa]">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-medium text-sm">{inv.description}</p>
                    <p className="text-xs text-muted-foreground">${inv.amount.toLocaleString()}</p>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <p className="text-[10px] uppercase tracking-widest font-semibold text-muted-foreground">Current Proof (${inv.amount.toLocaleString()})</p>
                  {inv.proof_of_payment_url ? (
                    <div className="flex items-center gap-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex-1 rounded-full gap-2 text-blue-600 border-blue-100 hover:bg-blue-50"
                        onClick={() => window.open(inv.proof_of_payment_url, '_blank')}
                      >
                        <Eye size={14} />
                        View
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex-1 rounded-full gap-2 text-slate-600 border-slate-200 hover:bg-slate-50"
                        onClick={() => handleDownload(inv.proof_of_payment_url!, `proof-${inv.id}.pdf`)}
                      >
                        <Download size={14} />
                        Download
                      </Button>
                      {inv.status === 'verifying' && (
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="rounded-full h-8 w-8 p-0 text-destructive hover:bg-destructive/10"
                          onClick={() => handleRemoveProof(inv.id)}
                        >
                          <Trash2 size={14} />
                        </Button>
                      )}
                    </div>
                  ) : (
                    <p className="text-xs italic text-muted-foreground">No current proof</p>
                  )}
                </div>

                {inv.proof_history && inv.proof_history.length > 0 && (
                  <div className="space-y-2 pt-2 border-t border-[#e5e5e5]">
                    <p className="text-[10px] uppercase tracking-widest font-semibold text-muted-foreground">History ({inv.proof_history.length})</p>
                    <div className="max-h-32 overflow-y-auto space-y-1 pr-2">
                      {inv.proof_history.map((url, idx) => (
                        <div key={idx} className="flex items-center justify-between p-2 bg-white border border-[#f0f0f0] rounded-lg">
                          <span className="text-[10px] font-medium">Version {idx + 1}</span>
                          <div className="flex gap-1">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-6 w-6 p-0 rounded-full"
                              onClick={() => window.open(url, '_blank')}
                            >
                              <Eye size={12} />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-6 w-6 p-0 rounded-full text-slate-500"
                              onClick={() => handleDownload(url, `proof-${inv.id}-v${idx + 1}.pdf`)}
                            >
                              <Download size={12} />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
            {invoices.filter(inv => inv.proof_of_payment_url || (inv.proof_history && inv.proof_history.length > 0)).length === 0 && (
              <div className="col-span-full p-12 text-center border border-dashed border-[#e5e5e5] rounded-2xl text-muted-foreground italic">
                No payment proofs have been uploaded yet.
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Dialog open={isUploadOpen} onOpenChange={setIsUploadOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="font-serif text-2xl">Upload Payment Proof</DialogTitle>
            <DialogDescription>Provide a URL to your payment screenshot or PDF receipt.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {!selectedInvoiceId && (
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest font-semibold">Select Invoice</label>
                <select 
                  className="w-full p-2 border rounded-md text-sm"
                  onChange={(e) => setSelectedInvoiceId(e.target.value)}
                >
                  <option value="">Select an invoice...</option>
                  {invoices.map(inv => (
                    <option key={inv.id} value={inv.id}>{inv.description} - ${inv.amount}</option>
                  ))}
                </select>
              </div>
            )}
            <div className="space-y-4">
              <div className="flex items-center justify-center w-full">
                <FileUpload 
                  title="Upload Payment Proof"
                  path={`proofs/${profile?.id}`}
                  metadata={{ user_id: profile?.id!, type: 'payment-proof', invoice_id: selectedInvoiceId! }}
                  onUploadSuccess={async (url) => {
                    const invoice = invoices.find(i => i.id === selectedInvoiceId);
                    const newHistory = [...(invoice?.proof_history || []), url];
                    
                    await supabase.from('invoices').update({
                      proof_of_payment_url: url,
                      proof_history: newHistory,
                      status: 'verifying'
                    }).eq('id', selectedInvoiceId!);
                    
                    setIsUploadOpen(false);
                    setSelectedInvoiceId(null);
                    toast.success('Payment proof uploaded for verification');
                    
                    // Refresh invoices
                    const { data } = await supabase.from('invoices').select('*').eq('client_id', profile!.id).order('date', { ascending: false });
                    setInvoices(data || []);
                  }}
                />
              </div>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-[#e5e5e5]" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-white px-2 text-muted-foreground">Or provide URL</span>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest font-semibold">Proof URL</label>
                <Input 
                  placeholder="https://example.com/payment-proof.jpg" 
                  value={proofUrl}
                  onChange={e => setProofUrl(e.target.value)}
                />
              </div>
            </div>
            <Button onClick={handleUploadProof} className="w-full bg-[#1a1a1a] text-white rounded-full">
              Submit for Verification
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function StatCard({ title, value, icon, className }: { title: string, value: string, icon: React.ReactNode, className?: string }) {
  return (
    <Card className="border-[#e5e5e5] shadow-sm">
      <CardContent className="pt-6">
        <div className="flex justify-between items-start">
          <div className="space-y-1">
            <p className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground font-semibold">{title}</p>
            <p className={cn("text-3xl font-serif", className)}>{value}</p>
          </div>
          <div className="p-2 bg-[#f5f5f5] rounded-lg text-[#1a1a1a]">
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
