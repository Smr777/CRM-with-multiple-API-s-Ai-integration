import { useEffect, useState } from 'react';
import { useAuth } from '../lib/AuthContext';
import { supabase } from '../lib/supabase';
import { Message } from '../types';
import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Send, MessageSquare, Clock, CheckCircle2 } from 'lucide-react';
import { safeFormatDate } from '../lib/date-utils';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export default function Messages() {
  const { profile } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!profile) return;
    const fetchMessages = async () => {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .eq('client_id', profile.id)
        .order('created_at', { ascending: false });
      
      if (error) {
        console.error("Messages fetch error:", error);
      } else {
        setMessages(data || []);
      }
    };
    fetchMessages();
  }, [profile]);

  const handleSendMessage = async () => {
    if (!profile || !subject || !body) return;
    setSubmitting(true);
    try {
      const { error } = await supabase.from('messages').insert({
        client_id: profile.id,
        subject,
        body,
        created_at: new Date().toISOString(),
        status: 'new'
      });
      if (error) throw error;
      toast.success('Message sent to admin');
      setSubject('');
      setBody('');
    } catch (error) {
      toast.error('Failed to send message');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-12">
      <header className="space-y-2">
        <h1 className="text-4xl font-serif">Secure Messaging</h1>
        <p className="text-muted-foreground font-light tracking-wide">Direct, structured communication with your consulting team.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Message Form */}
        <div className="lg:col-span-1 space-y-6">
          <Card className="border-[#e5e5e5] shadow-sm">
            <CardHeader>
              <CardTitle className="font-serif text-xl">New Request</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest font-semibold">Subject</label>
                <Input 
                  placeholder="e.g. Schedule Update" 
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest font-semibold">Message</label>
                <Textarea 
                  placeholder="Describe your request in detail..." 
                  className="min-h-[150px]"
                  value={body}
                  onChange={(e) => setBody(e.target.value)}
                />
              </div>
              <Button 
                onClick={handleSendMessage}
                disabled={submitting || !subject || !body}
                className="w-full bg-[#1a1a1a] text-white rounded-full h-12 gap-2"
              >
                <Send size={18} />
                {submitting ? 'Sending...' : 'Send Message'}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Message History */}
        <div className="lg:col-span-2 space-y-6">
          <h2 className="text-2xl font-serif">Message History</h2>
          <div className="space-y-4">
            {messages.length > 0 ? messages.map((msg) => (
              <motion.div 
                key={msg.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="p-6 bg-white border border-[#e5e5e5] rounded-xl shadow-sm space-y-4"
              >
                <div className="flex justify-between items-start">
                  <div className="space-y-1">
                    <h3 className="font-medium text-lg">{msg.subject}</h3>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1"><Clock size={12} /> {safeFormatDate(msg.created_at, 'MMM d, h:mm a')}</span>
                      <Badge variant="outline" className={cn(
                        "rounded-full px-2 py-0 text-[10px] uppercase tracking-widest",
                        msg.status === 'replied' ? "bg-green-50 text-green-700 border-green-100" : "bg-blue-50 text-blue-700 border-blue-100"
                      )}>
                        {msg.status}
                      </Badge>
                    </div>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground font-light leading-relaxed">
                  {msg.body}
                </p>
              </motion.div>
            )) : (
              <div className="p-20 text-center border border-dashed border-[#e5e5e5] rounded-xl text-muted-foreground font-light italic">
                No message history found.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
