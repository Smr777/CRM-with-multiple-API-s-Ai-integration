import { useEffect, useState, ChangeEvent, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { UserProfile, Invoice, Contract, ClientAssessment } from '../types';
import ClientAssessmentManager from '../components/ClientAssessmentManager';
import { motion } from 'motion/react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileUpload } from '../components/FileUpload';
import { 
  ArrowLeft, 
  Settings, 
  FileText, 
  CreditCard, 
  ClipboardCheck, 
  Save,
  Upload,
  Sparkles,
  Eye,
  Trash2,
  History,
  Plus,
  Download,
  Calendar,
  CheckCircle2
} from 'lucide-react';
import jsPDF from 'jspdf';
import { toPng } from 'html-to-image';
import { toast } from 'sonner';
import { safeFormatDate } from '../lib/date-utils';
import { Badge } from '@/components/ui/badge';
import { FeedbackForm, FeedbackResponse } from '../types';
import { analyzeFeedback } from '../services/aiService';

import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogDescription
} from '@/components/ui/dialog';

export default function ClientView() {
  const { clientId } = useParams();
  const navigate = useNavigate();
  const [client, setClient] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [clientAssessments, setClientAssessments] = useState<ClientAssessment[]>([]);
  const [isReportOpen, setIsReportOpen] = useState(false);
  const [selectedResponseId, setSelectedResponseId] = useState<string | null>(null);
  const [reportUrl, setReportUrl] = useState('');
  
  // Admin edits
  const [instructions, setInstructions] = useState('');
  const [welcomePacketUrl, setWelcomePacketUrl] = useState('');
  const [uploadingReport, setUploadingReport] = useState(false);
  const [invoiceData, setInvoiceData] = useState({ amount: '', description: '' });
  const [contractData, setContractData] = useState<{
    content: string;
    sessionDuration: string;
    sessions: { dateTime: string; duration: string }[];
  }>({ 
    content: '', 
    sessionDuration: '60min',
    sessions: []
  });
  const [newSession, setNewSession] = useState({ dateTime: '', duration: '60min' });
  const [forms, setForms] = useState<Record<string, FeedbackForm>>({});
  const [analyzing, setAnalyzing] = useState<string | null>(null);
  const reportInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!clientId) return;
    
    const fetchData = async () => {
      setLoading(true);
      try {
        // Fetch profile
        const { data: profileData, error: profileError } = await supabase
          .from('users')
          .select('*')
          .eq('id', clientId)
          .single();
        
        if (profileError) throw profileError;
        setClient(profileData);
        setInstructions(profileData.welcome_instructions || '');
        setWelcomePacketUrl(profileData.welcome_packet_url || '');

        // Fetch invoices
        const { data: invoiceData, error: invoiceError } = await supabase
          .from('invoices')
          .select('*')
          .eq('client_id', clientId)
          .order('date', { ascending: false });
        if (invoiceError) throw invoiceError;
        setInvoices(invoiceData || []);

        // Fetch contracts
        const { data: contractData, error: contractError } = await supabase
          .from('contracts')
          .select('*')
          .eq('client_id', clientId)
          .order('created_at', { ascending: false });
        if (contractError) throw contractError;
        setContracts(contractData || []);

        // Fetch assessments
        const { data: assessmentData, error: assessmentError } = await supabase
          .from('client_assessments')
          .select('*')
          .eq('client_id', clientId)
          .order('updated_at', { ascending: false });
        if (assessmentError) throw assessmentError;
        setClientAssessments(assessmentData || []);

        // Fetch forms
        const { data: formData, error: formError } = await supabase
          .from('feedback_forms')
          .select('*');
        if (formError) throw formError;
        const formsMap: Record<string, FeedbackForm> = {};
        formData?.forEach(f => formsMap[f.id] = f);
        setForms(formsMap);

      } catch (error: any) {
        console.error("Error fetching client data:", error);
        const errorMessage = error.message || (typeof error === 'string' ? error : "Unknown error");
        toast.error(`Failed to load client data: ${errorMessage}`);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [clientId]);

  const handleAnalyze = async (response: FeedbackResponse) => {
    const form = forms[response.form_id];
    if (!form) return;
    
    setAnalyzing(response.id);
    try {
      const analysis = await analyzeFeedback(response.responses, form.questions);
      if (analysis) {
        const { error } = await supabase.from('feedback_responses').update({
          ai_analysis: analysis
        }).eq('id', response.id);
        
        if (error) throw error;
        toast.success('AI Analysis complete');
      }
    } catch (error) {
      toast.error('AI Analysis failed');
    } finally {
      setAnalyzing(null);
    }
  };

  const downloadContract = async (contractId: string) => {
    console.log('Attempting to download contract:', contractId);
    const element = document.getElementById(`printable-contract-${contractId}`);
    if (!element) {
      toast.error('Contract element not found');
      return;
    }
    try {
      toast.loading('Generating PDF...', { id: 'pdf-gen' });
      
      // Ensure the element is visible for capture
      const originalStyle = element.style.display;
      element.style.display = 'block';
      
      // Add a small delay to ensure rendering is complete
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const dataUrl = await toPng(element, {
        quality: 1.0,
        pixelRatio: 3,
        backgroundColor: '#ffffff',
        width: 800,
        style: {
          display: 'block'
        }
      });
      
      element.style.display = originalStyle;
      
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgProperties = pdf.getImageProperties(dataUrl);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProperties.height * pdfWidth) / imgProperties.width;
      
      pdf.addImage(dataUrl, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`contract-${contractId}.pdf`);
      toast.success('Contract downloaded', { id: 'pdf-gen' });
    } catch (error) {
      console.error('PDF generation details:', error);
      toast.error(`Failed to generate PDF: ${error instanceof Error ? error.message : 'Unknown error'}`, { id: 'pdf-gen' });
    }
  };

  const handleUpdateInstructions = async () => {
    if (!clientId) return;
    try {
      const { error } = await supabase.from('users').update({
        welcome_instructions: instructions,
        welcome_packet_url: welcomePacketUrl
      }).eq('id', clientId);
      
      if (error) throw error;
      toast.success('Client profile updated');
    } catch (error) {
      toast.error('Failed to update client profile');
    }
  };

  const handleSendInvoice = async () => {
    if (!clientId || !invoiceData.amount) return;
    try {
      const { error } = await supabase.from('invoices').insert({
        client_id: clientId,
        amount: parseFloat(invoiceData.amount),
        description: invoiceData.description,
        status: 'unpaid',
        date: new Date().toISOString()
      });
      
      if (error) throw error;
      
      toast.success('Invoice sent');
      setInvoiceData({ amount: '', description: '' });
      // Refresh invoices
      const { data } = await supabase.from('invoices').select('*').eq('client_id', clientId).order('date', { ascending: false });
      if (data) setInvoices(data);
    } catch (error) {
      toast.error('Failed to send invoice');
    }
  };

  const handleCreateContract = async () => {
    if (!clientId || !contractData.content) return;
    try {
      const { error } = await supabase.from('contracts').insert({
        client_id: clientId,
        content: contractData.content,
        status: 'pending',
        created_at: new Date().toISOString(),
        session_date_time: contractData.sessions[0]?.dateTime || null,
        session_duration: contractData.sessions[0]?.duration || null
      });
      
      if (error) throw error;
      
      toast.success('Contract created and sent to client');
      setContractData({ 
        content: '', 
        sessionDuration: '60min',
        sessions: []
      });
      // Refresh contracts
      const { data } = await supabase.from('contracts').select('*').eq('client_id', clientId).order('created_at', { ascending: false });
      if (data) setContracts(data);
    } catch (error) {
      toast.error('Failed to create contract');
    }
  };

  const handleUploadReport = async () => {
    if (!selectedResponseId || !reportUrl) return;
    try {
      const { error } = await supabase.from('client_assessments').update({
        report_url: reportUrl,
        status: 'completed'
      }).eq('id', selectedResponseId);
      
      if (error) throw error;
      
      toast.success('Report uploaded');
      setIsReportOpen(false);
      setReportUrl('');
      setSelectedResponseId(null);
      // Refresh assessments
      const { data } = await supabase.from('client_assessments').select('*').eq('client_id', clientId!).order('updated_at', { ascending: false });
      if (data) setClientAssessments(data);
    } catch (error) {
      toast.error('Failed to upload report');
    }
  };

  const handleUpdateInvoiceStatus = async (invoiceId: string, status: string) => {
    try {
      const { error } = await supabase.from('invoices').update({ status }).eq('id', invoiceId);
      if (error) throw error;
      toast.success('Invoice status updated');
      // Refresh invoices
      const { data } = await supabase.from('invoices').select('*').eq('client_id', clientId!).order('date', { ascending: false });
      if (data) setInvoices(data);
    } catch (error) {
      toast.error('Failed to update status');
    }
  };

  const handleDownload = async (url: string, filename: string) => {
    try {
      // Use the server-side proxy to bypass CORS
      const proxyUrl = `/api/proxy-download?url=${encodeURIComponent(url)}&filename=${encodeURIComponent(filename)}`;
      
      const response = await fetch(proxyUrl);
      if (!response.ok) throw new Error('Download failed');
      
      const blob = await response.blob();
      const contentType = blob.type;

      // If it's already a PDF, just download it
      if (contentType === 'application/pdf') {
        const blobUrl = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = blobUrl;
        link.download = filename.endsWith('.pdf') ? filename : `${filename}.pdf`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(blobUrl);
        return;
      }

      // If it's an image, convert it to PDF as requested
      if (contentType.startsWith('image/')) {
        const img = new Image();
        const imageUrl = window.URL.createObjectURL(blob);
        
        img.onload = () => {
          const pdf = new jsPDF({
            orientation: img.width > img.height ? 'landscape' : 'portrait',
            unit: 'px',
            format: [img.width, img.height]
          });
          
          pdf.addImage(imageUrl, 'JPEG', 0, 0, img.width, img.height);
          pdf.save(filename.endsWith('.pdf') ? filename : `${filename}.pdf`);
          window.URL.revokeObjectURL(imageUrl);
        };
        
        img.onerror = () => {
          toast.error('Failed to process image for PDF conversion');
        };
        
        img.src = imageUrl;
        return;
      }

      // Fallback for other types
      const blobUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    } catch (error) {
      console.error('Download failed:', error);
      toast.error('Failed to download file. Opening in new tab instead.');
      window.open(url, '_blank');
    }
  };

  const totalBilled = invoices.reduce((acc, inv) => acc + inv.amount, 0);
  const assessmentsCompleted = clientAssessments.filter(a => a.status === 'completed').length;
  const totalAssessments = clientAssessments.length;

  if (loading) return <div className="p-20 text-center">Loading client profile...</div>;
  console.log('Client:', client);
  if (!client) return <div className="p-20 text-center">Client not found.</div>;

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-20">
      <Button 
        variant="ghost" 
        onClick={() => navigate('/admin')}
        className="rounded-full gap-2 text-muted-foreground hover:text-[#1a1a1a]"
      >
        <ArrowLeft size={16} />
        Back to Dashboard
      </Button>

      <header className="flex items-center justify-between">
        <div className="space-y-1">
          <h1 className="text-4xl font-serif">{client.display_name}</h1>
          <p className="text-muted-foreground font-light tracking-wide">{client.email} • Joined {safeFormatDate(client.created_at, 'MMMM yyyy')}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="rounded-full">Edit Profile</Button>
          <Button className="bg-[#1a1a1a] text-white rounded-full">Message Client</Button>
        </div>
      </header>

      <Tabs defaultValue="overview" className="space-y-8">
        <TabsList className="bg-transparent border-b rounded-none w-full justify-start h-auto p-0 gap-8">
          <TabsTrigger value="overview" className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#1a1a1a] data-[state=active]:bg-transparent px-0 pb-4 text-sm font-medium">Overview</TabsTrigger>
          <TabsTrigger value="billing" className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#1a1a1a] data-[state=active]:bg-transparent px-0 pb-4 text-sm font-medium">Billing & Invoices</TabsTrigger>
          <TabsTrigger value="proofs" className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#1a1a1a] data-[state=active]:bg-transparent px-0 pb-4 text-sm font-medium">Payment Proofs</TabsTrigger>
          <TabsTrigger value="assessments" className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#1a1a1a] data-[state=active]:bg-transparent px-0 pb-4 text-sm font-medium">Assessments</TabsTrigger>
          <TabsTrigger value="contract" className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#1a1a1a] data-[state=active]:bg-transparent px-0 pb-4 text-sm font-medium">Contract</TabsTrigger>
          <TabsTrigger value="feedback" className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#1a1a1a] data-[state=active]:bg-transparent px-0 pb-4 text-sm font-medium">Feedback Analysis</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="border-[#e5e5e5] shadow-sm">
              <CardHeader>
                <CardTitle className="font-serif text-xl flex items-center gap-2">
                  <Settings size={18} />
                  Client Setup
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest font-semibold">Dashboard Instructions</label>
                  <Textarea 
                    value={instructions}
                    onChange={(e) => setInstructions(e.target.value)}
                    placeholder="Custom instructions for this client's dashboard..."
                    className="min-h-[150px] font-light leading-relaxed"
                  />
                </div>
                <Button onClick={handleUpdateInstructions} className="w-full bg-[#1a1a1a] text-white rounded-full gap-2">
                  <Save size={16} />
                  Save Client Settings
                </Button>
              </CardContent>
            </Card>

            <Card className="border-[#e5e5e5] shadow-sm">
              <CardHeader>
                <CardTitle className="font-serif text-xl flex items-center gap-2">
                  <FileText size={18} />
                  Welcome Packet
                </CardTitle>
                <CardDescription>Upload a PDF welcome packet for the client to view.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                  {welcomePacketUrl ? (
                    <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-white rounded-lg border border-slate-200">
                          <FileText size={20} className="text-blue-600" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Welcome Packet PDF</p>
                          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Ready for client</p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="rounded-full h-8 w-8 p-0"
                          onClick={() => window.open(welcomePacketUrl, '_blank')}
                        >
                          <Eye size={14} />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="rounded-full h-8 w-8 p-0 text-destructive hover:bg-destructive/10"
                          onClick={async () => {
                            if (!clientId) return;
                            setWelcomePacketUrl('');
                            await supabase.from('users').update({
                              welcome_packet_url: ''
                            }).eq('id', clientId);
                            toast.success('Welcome packet removed');
                          }}
                        >
                          <Trash2 size={14} />
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <FileUpload 
                        title="Upload Packet"
                        path={`welcome-packets/${clientId}`}
                        metadata={{ user_id: clientId!, type: 'welcome-packet' }}
                        onUploadSuccess={(url) => {
                          setWelcomePacketUrl(url);
                          supabase.from('users').update({
                            welcome_packet_url: url
                          }).eq('id', clientId!);
                          toast.success('Welcome packet uploaded successfully');
                        }}
                      />
                      <div className="relative">
                        <div className="absolute inset-0 flex items-center">
                          <span className="w-full border-t border-[#e5e5e5]" />
                        </div>
                        <div className="relative flex justify-center text-xs uppercase">
                          <span className="bg-white px-2 text-muted-foreground">Or provide URL</span>
                        </div>
                      </div>
                      <Input 
                        value={welcomePacketUrl}
                        onChange={(e) => setWelcomePacketUrl(e.target.value)}
                        placeholder="Paste PDF URL here..."
                        className="font-light"
                      />
                    </div>
                  )}
              </CardContent>
            </Card>

            <div className="space-y-8">
              <Card className="border-[#e5e5e5] shadow-sm">
                <CardHeader>
                  <CardTitle className="font-serif text-xl">Client Stats</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center py-2 border-b border-[#f5f5f5]">
                    <span className="text-sm text-muted-foreground">Client Type</span>
                    <span className="text-sm font-medium uppercase tracking-wider">{client.client_type}</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-[#f5f5f5]">
                    <span className="text-sm text-muted-foreground">Assessments Completed</span>
                    <span className="text-sm font-medium">{assessmentsCompleted} / {totalAssessments}</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-[#f5f5f5]">
                    <span className="text-sm text-muted-foreground">Total Billed</span>
                    <span className="text-sm font-medium">${totalBilled.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="proofs" className="space-y-8">
          <Card className="border-[#e5e5e5] shadow-sm">
            <CardHeader>
              <CardTitle className="font-serif text-xl flex items-center gap-2">
                <FileText size={18} />
                Client Payment Proofs
              </CardTitle>
              <CardDescription>View all payment proofs uploaded by the client across all invoices.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {invoices.filter(inv => inv.proof_of_payment_url || (inv.proof_history && inv.proof_history.length > 0)).map((inv) => (
                  <div key={inv.id} className="p-4 border border-[#e5e5e5] rounded-xl space-y-4 bg-[#fafafa]">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium text-sm">{inv.description}</p>
                        <p className="text-xs text-muted-foreground">${inv.amount.toLocaleString()} • {safeFormatDate(inv.date, 'MMM d, yyyy')}</p>
                      </div>
                      <Badge className={cn(
                        "rounded-full px-2 py-0.5 text-[8px] uppercase tracking-widest",
                        inv.status === 'paid' ? "bg-green-50 text-green-700 border-green-100" : 
                        inv.status === 'verifying' ? "bg-blue-50 text-blue-700 border-blue-100" :
                        "bg-amber-50 text-amber-700 border-amber-100"
                      )}>
                        {inv.status}
                      </Badge>
                    </div>
                    
                    <div className="space-y-2">
                      <p className="text-[10px] uppercase tracking-widest font-semibold text-muted-foreground">Current Proof</p>
                      {inv.proof_of_payment_url ? (
                        <div className="flex gap-2">
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="flex-1 rounded-full gap-2 text-blue-600 border-blue-100 hover:bg-blue-50"
                            onClick={() => window.open(inv.proof_of_payment_url, '_blank')}
                          >
                            <Eye size={14} />
                            View
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="flex-1 rounded-full gap-2 text-slate-600 border-slate-200 hover:bg-slate-50"
                            onClick={() => handleDownload(inv.proof_of_payment_url!, `proof-${inv.id}.pdf`)}
                          >
                            <Download size={14} />
                            Download
                          </Button>
                        </div>
                      ) : (
                        <p className="text-xs italic text-muted-foreground">No current proof uploaded</p>
                      )}
                    </div>

                    {inv.proof_history && inv.proof_history.length > 0 && (
                      <div className="space-y-2 pt-2 border-t border-[#e5e5e5]">
                        <p className="text-[10px] uppercase tracking-widest font-semibold text-muted-foreground">History ({inv.proof_history.length})</p>
                        <div className="max-h-32 overflow-y-auto space-y-1 pr-2">
                          {inv.proof_history.map((url, idx) => (
                            <div key={idx} className="flex items-center justify-between p-2 bg-white border border-[#f0f0f0] rounded-lg">
                              <span className="text-[10px] font-medium">Version {idx + 1}</span>
                              <div className="flex gap-1">
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="h-6 w-6 p-0 rounded-full"
                                  onClick={() => window.open(url, '_blank')}
                                  title="View"
                                >
                                  <Eye size={12} />
                                </Button>
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="h-6 w-6 p-0 rounded-full text-slate-500"
                                  onClick={() => handleDownload(url, `proof-${inv.id}-v${idx + 1}.pdf`)}
                                  title="Download"
                                >
                                  <Download size={12} />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
                {invoices.filter(inv => inv.proof_of_payment_url || (inv.proof_history && inv.proof_history.length > 0)).length === 0 && (
                  <div className="col-span-full p-12 text-center border border-dashed border-[#e5e5e5] rounded-2xl text-muted-foreground italic">
                    No payment proofs have been uploaded by this client yet.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="billing" className="space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <Card className="border-[#e5e5e5] shadow-sm lg:col-span-1">
              <CardHeader>
                <CardTitle className="font-serif text-xl">Create New Invoice</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest font-semibold">Amount ($)</label>
                  <Input 
                    type="number" 
                    placeholder="0.00"
                    value={invoiceData.amount}
                    onChange={(e) => setInvoiceData({...invoiceData, amount: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest font-semibold">Description</label>
                  <Input 
                    placeholder="Consulting Fee - April"
                    value={invoiceData.description}
                    onChange={(e) => setInvoiceData({...invoiceData, description: e.target.value})}
                  />
                </div>
                <Button onClick={handleSendInvoice} className="w-full bg-[#1a1a1a] text-white rounded-full">
                  Send Invoice
                </Button>
              </CardContent>
            </Card>

            <Card className="border-[#e5e5e5] shadow-sm lg:col-span-2 overflow-hidden">
              <CardHeader className="bg-[#f9f9f9] border-b border-[#e5e5e5]">
                <CardTitle className="font-serif text-xl">Invoice History</CardTitle>
              </CardHeader>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-[#f9f9f9] border-b border-[#e5e5e5]">
                    <tr>
                      <th className="text-left p-4 font-serif">Date</th>
                      <th className="text-left p-4 font-serif">Description</th>
                      <th className="text-left p-4 font-serif">Amount</th>
                      <th className="text-left p-4 font-serif">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {invoices.map((inv) => (
                      <tr key={inv.id} className="border-b border-[#f5f5f5] last:border-0">
                        <td className="p-4 text-muted-foreground">{safeFormatDate(inv.date, 'MMM d, yyyy')}</td>
                        <td className="p-4 font-medium">{inv.description}</td>
                        <td className="p-4">${inv.amount.toLocaleString()}</td>
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <select 
                              value={inv.status}
                              onChange={(e) => handleUpdateInvoiceStatus(inv.id, e.target.value)}
                              className={cn(
                                "text-[10px] uppercase tracking-widest border rounded-full px-2 py-1 outline-none",
                                inv.status === 'paid' ? "bg-green-50 text-green-700 border-green-100" : 
                                inv.status === 'verifying' ? "bg-blue-50 text-blue-700 border-blue-100" :
                                "bg-amber-50 text-amber-700 border-amber-100"
                              )}
                            >
                              <option value="unpaid">Unpaid</option>
                              <option value="verifying">Verifying</option>
                              <option value="paid">Paid</option>
                            </select>
                            
                            {inv.proof_of_payment_url && (
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="h-7 px-2 text-[10px] rounded-full gap-1 text-blue-600 hover:bg-blue-50"
                                onClick={() => window.open(inv.proof_of_payment_url, '_blank')}
                              >
                                <Eye size={12} />
                                Current
                              </Button>
                            )}

                            {inv.proof_history && inv.proof_history.length > 0 && (
                              <Dialog>
                                <DialogTrigger 
                                  render={
                                    <Button variant="ghost" size="sm" className="h-7 px-2 text-[10px] rounded-full gap-1 text-slate-600 hover:bg-slate-50">
                                      <History size={12} />
                                      History ({inv.proof_history.length})
                                    </Button>
                                  } 
                                />
                                <DialogContent className="sm:max-w-[425px]">
                                  <DialogHeader>
                                    <DialogTitle className="font-serif text-2xl">Proof History</DialogTitle>
                                    <DialogDescription>All documents uploaded by the client for this invoice.</DialogDescription>
                                  </DialogHeader>
                                  <div className="space-y-4 py-4">
                                    {inv.proof_history.map((url, idx) => (
                                      <div key={idx} className="flex items-center justify-between p-3 bg-slate-50 border border-slate-100 rounded-xl">
                                        <div className="flex items-center gap-3">
                                          <div className="p-2 bg-white rounded-lg border border-slate-200">
                                            <FileText size={16} className="text-blue-600" />
                                          </div>
                                          <div>
                                            <p className="text-xs font-medium">Version {idx + 1}</p>
                                            <p className="text-[10px] text-muted-foreground">Uploaded Proof</p>
                                          </div>
                                        </div>
                                        <Button 
                                          variant="outline" 
                                          size="sm" 
                                          className="rounded-full h-8 w-8 p-0"
                                          onClick={() => window.open(url, '_blank')}
                                        >
                                          <Eye size={14} />
                                        </Button>
                                      </div>
                                    ))}
                                  </div>
                                </DialogContent>
                              </Dialog>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                    {invoices.length === 0 && (
                      <tr>
                        <td colSpan={4} className="p-8 text-center text-muted-foreground italic">No invoices found.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="assessments" className="space-y-8">
          <ClientAssessmentManager 
            clientId={clientId!} 
            onUploadReport={(id) => {
              setSelectedResponseId(id);
              setIsReportOpen(true);
            }} 
          />
        </TabsContent>

        <TabsContent value="contract" className="space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <Card className="border-[#e5e5e5] shadow-sm lg:col-span-1">
              <CardHeader>
                <CardTitle className="font-serif text-xl">Create New Contract</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-widest font-semibold">Session Duration</label>
                    <select 
                      className="w-full p-2 border rounded-md text-sm"
                      value={contractData.sessionDuration}
                      onChange={(e) => setContractData({...contractData, sessionDuration: e.target.value})}
                    >
                      <option value="30min">30 Minutes</option>
                      <option value="45min">45 Minutes</option>
                      <option value="60min">60 Minutes</option>
                      <option value="90min">90 Minutes</option>
                    </select>
                  </div>
                </div>
                <div className="space-y-4">
                  <label className="text-xs uppercase tracking-widest font-semibold">Scheduled Sessions</label>
                  {contractData.sessions.map((session, i) => (
                    <div key={i} className="flex items-center justify-between p-2 bg-slate-50 rounded-md text-sm">
                      <span>{safeFormatDate(session.dateTime, 'EEEE, MMMM d, yyyy')}</span>
                      <Button variant="ghost" size="sm" onClick={() => setContractData({...contractData, sessions: contractData.sessions.filter((_, idx) => idx !== i)})}>
                        <Trash2 size={14} />
                      </Button>
                    </div>
                  ))}
                  <div className="flex gap-2">
                    <Input 
                      type="date" 
                      value={newSession.dateTime}
                      onChange={(e) => setNewSession({...newSession, dateTime: e.target.value})}
                    />
                    <Button onClick={() => {
                      if (!newSession.dateTime) return;
                      setContractData({...contractData, sessions: [...contractData.sessions, { dateTime: newSession.dateTime, duration: contractData.sessionDuration }]});
                      setNewSession({...newSession, dateTime: ''});
                    }} className="gap-2">
                      <Plus size={16} /> Add
                    </Button>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest font-semibold">Contract Terms</label>
                  <Textarea 
                    placeholder="Enter the contract terms and conditions..."
                    className="min-h-[150px]"
                    value={contractData.content}
                    onChange={(e) => setContractData({...contractData, content: e.target.value})}
                  />
                </div>
                <Button onClick={handleCreateContract} className="w-full bg-[#1a1a1a] text-white rounded-full">
                  Create & Send Contract
                </Button>
              </CardContent>
            </Card>

            <div className="lg:col-span-2 space-y-6">
              <h3 className="text-xl font-serif">Contract History</h3>
              {contracts.map((con) => (
                <div key={con.id} className="space-y-4">
                  {/* Hidden printable version */}
                  <div style={{ position: 'absolute', left: '-9999px', top: '-9999px' }}>
                    <div id={`printable-contract-${con.id}`} className="w-[800px] bg-white p-16 text-[#1a1a1a] font-sans">
                      <div className="text-center space-y-4 mb-12 border-b pb-8">
                        <h1 className="text-4xl font-serif">Digital Agreement</h1>
                        <p className="text-muted-foreground font-light tracking-wide uppercase text-xs">Consulting Service Agreement</p>
                        <p className="text-[10px] text-muted-foreground">Ref: {con.id}</p>
                      </div>
                      
                      <div className="prose prose-slate max-w-none font-bold leading-relaxed text-[#1a1a1a] space-y-6 text-xl mb-12 whitespace-pre-wrap break-words">
                        {con.content.split('\n').map((para, i) => (
                          <p key={i} className="break-words">{para}</p>
                        ))}
                      </div>

                      {con.session_date_time && (
                        <div className="space-y-4 mb-12 pt-8 border-t">
                          <h3 className="text-sm uppercase tracking-widest font-semibold text-muted-foreground">Scheduled Sessions</h3>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="p-4 bg-slate-50 rounded-lg border border-slate-100 flex items-center gap-3">
                              <Calendar size={16} className="text-muted-foreground" />
                              <span className="text-sm font-medium">{safeFormatDate(con.session_date_time, 'EEEE, MMMM d, yyyy')}</span>
                            </div>
                          </div>
                        </div>
                      )}

                      <div className="mt-16 pt-12 border-t grid grid-cols-2 gap-12">
                        <div className="space-y-4">
                          <h3 className="text-sm uppercase tracking-widest font-semibold text-muted-foreground">Brand Signature</h3>
                          <div className="h-24 flex items-end border-b pb-2">
                            <div className="flex flex-col">
                              <span className="font-serif text-3xl italic opacity-50">Anamika Mishra</span>
                              <span className="text-xs text-muted-foreground mt-1">(Anamika's Rationale Tranquillity)</span>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-4">
                          <h3 className="text-sm uppercase tracking-widest font-semibold text-muted-foreground">Client Signature</h3>
                          {con.status === 'signed' ? (
                            <div className="space-y-2">
                              <div className="h-24 flex items-end border-b pb-2">
                                <span className="font-serif text-3xl italic">{con.signature}</span>
                              </div>
                              <div className="flex items-center justify-between">
                                <p className="text-[10px] text-muted-foreground">
                                  Signed on {safeFormatDate(con.signed_at, 'EEEE, MMMM d, yyyy')}
                                </p>
                                <CheckCircle2 size={16} className="text-green-600" />
                              </div>
                            </div>
                          ) : (
                            <div className="h-24 flex items-end border-b border-dashed pb-2">
                              <span className="text-xs text-muted-foreground italic">Pending Signature</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  <Card className="border-[#e5e5e5] shadow-sm overflow-hidden">
                    <CardHeader className="flex flex-row items-center justify-between border-b border-[#f5f5f5] bg-[#fafafa]">
                      <div>
                        <CardTitle className="font-serif text-lg">Agreement Ref: {con.id?.slice(0, 8)}</CardTitle>
                        <CardDescription>
                          {con.status === 'signed' && con.signed_at
                            ? `Signed on ${safeFormatDate(con.signed_at, 'MMM d, yyyy')}` 
                            : 'Pending Signature'}
                        </CardDescription>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="rounded-full gap-2" onClick={() => window.open(`/contract/${con.id}`, '_blank')}>
                          <Eye size={14} /> View
                        </Button>
                        <Button variant="outline" size="sm" className="rounded-full gap-2" onClick={() => downloadContract(con.id)}>
                          <Download size={14} /> PDF
                        </Button>
                        <Badge variant={con.status === 'signed' ? "default" : "secondary"} className="rounded-full">
                          {con.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="max-h-40 overflow-hidden relative">
                        <div className="prose prose-slate max-w-none font-medium leading-relaxed text-[#1a1a1a] space-y-2 text-sm opacity-70 whitespace-pre-wrap break-words">
                          {con.content.split('\n').slice(0, 3).map((para, i) => (
                            <p key={i} className="break-words">{para}</p>
                          ))}
                          {con.content.split('\n').length > 3 && <p>...</p>}
                        </div>
                        <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-white to-transparent" />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ))}
              {contracts.length === 0 && (
                <div className="p-10 text-center border border-dashed border-[#e5e5e5] rounded-xl text-muted-foreground italic">
                  No contracts created for this client.
                </div>
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="feedback" className="space-y-8">
          <FeedbackAnalysis clientId={clientId!} />
        </TabsContent>
      </Tabs>

      <Dialog open={isReportOpen} onOpenChange={setIsReportOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="font-serif text-2xl">Upload Assessment Report</DialogTitle>
            <DialogDescription>Upload a PDF report or provide a URL.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-4">
              <div className="flex items-center justify-center w-full">
                <FileUpload 
                  title="Upload Assessment Report"
                  path={`reports/${clientId}`}
                  metadata={{ user_id: clientId!, type: 'assessment-report', context_id: selectedResponseId! }}
                  onUploadSuccess={(url) => {
                    supabase.from('client_assessments').update({
                      report_url: url,
                      status: 'completed'
                    }).eq('id', selectedResponseId!);
                    setIsReportOpen(false);
                    setSelectedResponseId(null);
                    toast.success('Assessment report uploaded successfully');
                  }}
                />
              </div>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-[#e5e5e5]" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-white px-2 text-muted-foreground">Or provide URL</span>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest font-semibold">Report URL (PDF)</label>
                <Input 
                  placeholder="https://example.com/report.pdf" 
                  value={reportUrl}
                  onChange={e => setReportUrl(e.target.value)}
                />
              </div>
            </div>
            <Button onClick={handleUploadReport} className="w-full bg-[#1a1a1a] text-white rounded-full">
              Save Report URL
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function FeedbackAnalysis({ clientId }: { clientId: string }) {
  const [responses, setResponses] = useState<FeedbackResponse[]>([]);
  const [forms, setForms] = useState<Record<string, FeedbackForm>>({});
  const [analyzing, setAnalyzing] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      const { data: responseData } = await supabase
        .from('feedback_responses')
        .select('*')
        .eq('client_id', clientId);
      setResponses(responseData || []);

      const { data: formData } = await supabase
        .from('feedback_forms')
        .select('*');
      const formsMap: Record<string, FeedbackForm> = {};
      formData?.forEach(f => formsMap[f.id] = f);
      setForms(formsMap);
    };

    fetchData();
  }, [clientId]);

  const handleAnalyze = async (response: FeedbackResponse) => {
    const form = forms[response.form_id];
    if (!form) return;
    
    setAnalyzing(response.id);
    try {
      const analysis = await analyzeFeedback(response.responses, form.questions);
      if (analysis) {
        const { error } = await supabase.from('feedback_responses').update({
          ai_analysis: analysis
        }).eq('id', response.id);
        
        if (error) throw error;
        toast.success('AI Analysis complete');
        // Refresh
        const { data } = await supabase.from('feedback_responses').select('*').eq('client_id', clientId);
        if (data) setResponses(data);
      }
    } catch (error) {
      toast.error('AI Analysis failed');
    } finally {
      setAnalyzing(null);
    }
  };

  return (
    <div className="space-y-8">
      {responses.map((res) => (
        <Card key={res.id} className="border-[#e5e5e5] shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="font-serif text-xl">{forms[res.form_id]?.title || 'Feedback Form'}</CardTitle>
              <CardDescription>Submitted on {safeFormatDate(res.submitted_at, 'MMM d, yyyy')}</CardDescription>
            </div>
            <Button 
              onClick={() => handleAnalyze(res)} 
              disabled={analyzing === res.id}
              variant="outline"
              className="rounded-full gap-2"
            >
              <Sparkles size={16} className="text-purple-600" />
              {res.ai_analysis ? 'Re-analyze' : 'Analyze with AI'}
            </Button>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <h4 className="text-xs uppercase tracking-widest font-semibold text-muted-foreground">Client Responses</h4>
                <div className="space-y-4">
                  {res.responses.map((text, i) => (
                    <div key={i} className="space-y-1">
                      <p className="text-[10px] font-medium text-muted-foreground">{forms[res.form_id]?.questions[i]}</p>
                      <p className="text-sm font-light italic">"{text}"</p>
                    </div>
                  ))}
                </div>
              </div>

              {res.ai_analysis && (
                <div className="space-y-6 bg-purple-50/30 p-6 rounded-xl border border-purple-100">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs uppercase tracking-widest font-semibold text-purple-700">AI Insights</h4>
                    <Badge className="bg-purple-100 text-purple-700 border-purple-200 rounded-full">
                      {res.ai_analysis.sentiment}
                    </Badge>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <p className="text-[10px] font-bold uppercase text-purple-600 mb-2">Key Patterns</p>
                      <ul className="list-disc list-inside text-sm font-light space-y-1">
                        {res.ai_analysis.patterns.map((p, i) => <li key={i}>{p}</li>)}
                      </ul>
                    </div>
                    <div>
                      <p className="text-[10px] font-bold uppercase text-purple-600 mb-2">Suggestions</p>
                      <ul className="list-disc list-inside text-sm font-light space-y-1">
                        {res.ai_analysis.suggestions.map((s, i) => <li key={i}>{s}</li>)}
                      </ul>
                    </div>
                    <div>
                      <p className="text-[10px] font-bold uppercase text-purple-600 mb-2">Hidden Insights</p>
                      <p className="text-sm font-light italic leading-relaxed">"{res.ai_analysis.insights}"</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
      
      {responses.length === 0 && (
        <div className="p-20 text-center border border-dashed border-[#e5e5e5] rounded-2xl text-muted-foreground font-light italic">
          No feedback submissions from this client yet.
        </div>
      )}
    </div>
  );
}
