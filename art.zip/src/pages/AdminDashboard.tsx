import React, { useEffect, useState, useMemo } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { UserProfile, Notice, Invoice, FeedbackForm, AssessmentTemplate, ClientAssessment } from '../types';
import AssessmentManager from '../components/AssessmentManager';
import { motion } from 'motion/react';
import { cn } from '@/lib/utils';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter,
  DialogDescription
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Search, Plus, Mail, Bell, ExternalLink, Users, TrendingUp, CheckCircle2, DollarSign, Calendar, UserPlus, Trash2, XCircle, ClipboardCheck, MessageSquarePlus, Copy } from 'lucide-react';
import { toast } from 'sonner';
import { safeFormatDate } from '../lib/date-utils';

export default function AdminDashboard() {
  const [searchParams] = useSearchParams();
  const view = searchParams.get('view') || 'overview';
  
  const [clients, setClients] = useState<UserProfile[]>([]);
  const [allAssessments, setAllAssessments] = useState<ClientAssessment[]>([]);
  const [assessmentTemplates, setAssessmentTemplates] = useState<AssessmentTemplate[]>([]);
  const [allInvoices, setAllInvoices] = useState<Invoice[]>([]);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [invites, setInvites] = useState<any[]>([]);
  const [feedbackForms, setFeedbackForms] = useState<FeedbackForm[]>([]);
  const [allMessages, setAllMessages] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isNoticeOpen, setIsNoticeOpen] = useState(false);
  const [isInviteOpen, setIsInviteOpen] = useState(false);
  const [isFeedbackFormOpen, setIsFeedbackFormOpen] = useState(false);
  const [isBulkEmailOpen, setIsBulkEmailOpen] = useState(false);
  const [isReplyOpen, setIsReplyOpen] = useState(false);
  const [selectedMessageId, setSelectedMessageId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');
  const [noticeData, setNoticeData] = useState({ title: '', content: '', target: 'all' });
  const [inviteData, setInviteData] = useState({ name: '', email: '', client_type: 'individual' });
  const [feedbackFormData, setFeedbackFormData] = useState({ title: '', questions: [''], active: true });
  const [bulkEmailData, setBulkEmailData] = useState({ subject: '', body: '', target: 'all' });
  const [sendingBulk, setSendingBulk] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const { data: clientsData, error: clientsError } = await supabase.from('users').select('*').eq('role', 'client');
        if (clientsError) throw clientsError;
        setClients(clientsData || []);

        const { data: assessmentsData, error: assessmentsError } = await supabase.from('client_assessments').select('*');
        if (assessmentsError) throw assessmentsError;
        setAllAssessments(assessmentsData || []);

        const { data: templatesData, error: templatesError } = await supabase.from('assessment_templates').select('*');
        if (templatesError) throw templatesError;
        setAssessmentTemplates(templatesData || []);

        const { data: invoicesData, error: invoicesError } = await supabase.from('invoices').select('*');
        if (invoicesError) throw invoicesError;
        setAllInvoices(invoicesData || []);

        const { data: noticesData, error: noticesError } = await supabase.from('notices').select('*').order('created_at', { ascending: false });
        if (noticesError) throw noticesError;
        setNotices(noticesData || []);

        const { data: invitesData, error: invitesError } = await supabase.from('invites').select('*').order('created_at', { ascending: false });
        if (invitesError) throw invitesError;
        setInvites(invitesData || []);

        const { data: feedbackFormsData, error: feedbackError } = await supabase.from('feedback_forms').select('*');
        if (feedbackError) throw feedbackError;
        setFeedbackForms(feedbackFormsData || []);

        const { data: messagesData, error: messagesError } = await supabase.from('messages').select('*').order('created_at', { ascending: false });
        if (messagesError) throw messagesError;
        setAllMessages(messagesData || []);
      } catch (error: any) {
        console.error("Admin Dashboard fetch error:", error);
        toast.error(`Failed to load admin data: ${error.message || "Unknown error"}`);
      }
    };
    fetchData();
  }, []);

  const stats = useMemo(() => {
    const totalBilled = allInvoices.reduce((sum, inv) => sum + (Number(inv.amount) || 0), 0);
    const completedAssessments = allAssessments.length;
    return {
      totalClients: clients.length,
      activeAssessments: completedAssessments,
      revenue: totalBilled,
      pendingInvoices: allInvoices.filter(i => i.status === 'unpaid').length,
      newMessages: allMessages.filter(m => m.status === 'new').length
    };
  }, [clients, allAssessments, allInvoices, allMessages]);

  const handlePostNotice = async () => {
    if (!noticeData.title || !noticeData.content) return;
    try {
      const { error } = await supabase.from('notices').insert({
        ...noticeData,
        created_at: new Date().toISOString(),
      });
      if (error) throw error;
      toast.success('Notice posted successfully');
      setIsNoticeOpen(false);
      setNoticeData({ title: '', content: '', target: 'all' });
    } catch (error) {
      toast.error('Failed to post notice');
    }
  };

  const handleInviteClient = async () => {
    if (!inviteData.name || !inviteData.email) {
      toast.error('Please fill in all fields');
      return;
    }

    // Check if an active invite already exists for this email
    const existingInvite = invites.find(i => i.email.toLowerCase() === inviteData.email.toLowerCase() && i.status === 'pending');
    if (existingInvite) {
      toast.error('A pending invitation already exists for this email. Please cancel it first to send a new one.');
      return;
    }

    // Check if a client with this email already exists
    const existingClient = clients.find(c => c.email.toLowerCase() === inviteData.email.toLowerCase());
    if (existingClient) {
      toast.error('A client with this email already exists.');
      return;
    }

    try {
      // 1. Save to database - normalize email to lowercase
      const normalizedEmail = inviteData.email.toLowerCase();
      const { error } = await supabase.from('invites').insert({
        ...inviteData,
        email: normalizedEmail,
        status: 'pending',
        created_at: new Date().toISOString(),
      });
      if (error) throw error;

      // 2. Send actual email via backend
      const response = await fetch('/api/send-invite', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...inviteData,
          clientType: inviteData.client_type, // Fix: server expects clientType
          origin: window.location.origin
        }),
      });

      const result = await response.json();

      if (response.ok) {
        toast.success(`Invite sent to ${inviteData.email}`);
      } else {
        toast.error(result.error || 'Failed to send email');
      }

      setIsInviteOpen(false);
      setInviteData({ name: '', email: '', client_type: 'individual' });
      
      // Refresh invites
      const { data: updatedInvites } = await supabase.from('invites').select('*').order('created_at', { ascending: false });
      if (updatedInvites) setInvites(updatedInvites);

    } catch (error: any) {
      console.error('Invite error:', error);
      toast.error(error.message || 'Failed to process invitation');
    }
  };

  const handleCancelInvite = async (inviteId: string) => {
    try {
      const { error } = await supabase.from('invites').delete().eq('id', inviteId);
      if (error) throw error;
      toast.success('Invitation cancelled');
      
      // Refresh invites
      const { data: updatedInvites } = await supabase.from('invites').select('*').order('created_at', { ascending: false });
      if (updatedInvites) setInvites(updatedInvites);
    } catch (error) {
      toast.error('Failed to cancel invitation');
    }
  };

  const handleCopyInviteLink = (email: string) => {
    const link = `${window.location.origin}/login?invite=${encodeURIComponent(email)}`;
    navigator.clipboard.writeText(link);
    toast.success('Invite link copied to clipboard');
  };

  const handleTestLogin = (email: string) => {
    const link = `${window.location.origin}/login?invite=${encodeURIComponent(email)}`;
    window.open(link, '_blank');
  };

  const handleRemoveClient = async (clientId: string) => {
    try {
      const { error } = await supabase.from('users').delete().eq('id', clientId);
      if (error) throw error;
      toast.success('Client removed successfully');
      
      // Refresh clients
      const { data: updatedClients } = await supabase.from('users').select('*').order('created_at', { ascending: false });
      if (updatedClients) setClients(updatedClients || []);
    } catch (error) {
      toast.error('Failed to remove client');
    }
  };

  const handleCreateFeedbackForm = async () => {
    if (!feedbackFormData.title || feedbackFormData.questions.some(q => !q)) {
      toast.error('Please fill in all fields');
      return;
    }
    try {
      const { error } = await supabase.from('feedback_forms').insert(feedbackFormData);
      if (error) throw error;
      toast.success('Feedback form created');
      setIsFeedbackFormOpen(false);
      setFeedbackFormData({ title: '', questions: [''], active: true });
    } catch (error) {
      toast.error('Failed to create feedback form');
    }
  };

  const handleDeleteFeedbackForm = async (id: string) => {
    try {
      const { error } = await supabase.from('feedback_forms').delete().eq('id', id);
      if (error) throw error;
      toast.success('Form deleted');
    } catch (error) {
      toast.error('Failed to delete form');
    }
  };

  const handleBulkEmail = async () => {
    if (!bulkEmailData.subject || !bulkEmailData.body) {
      toast.error('Please fill in all fields');
      return;
    }

    setSendingBulk(true);
    try {
      const recipients = clients
        .filter(c => bulkEmailData.target === 'all' || c.client_type === bulkEmailData.target)
        .map(c => c.email);

      if (recipients.length === 0) {
        toast.error('No recipients found for the selected target');
        return;
      }

      const response = await fetch('/api/bulk-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          recipients,
          subject: bulkEmailData.subject,
          body: bulkEmailData.body
        }),
      });

      if (response.ok) {
        toast.success(`Bulk email sent to ${recipients.length} clients`);
        setIsBulkEmailOpen(false);
        setBulkEmailData({ subject: '', body: '', target: 'all' });
      } else {
        const result = await response.json();
        toast.error(result.error || 'Failed to send bulk email');
      }
    } catch (error) {
      toast.error('Failed to process bulk email');
    } finally {
      setSendingBulk(false);
    }
  };

  const handleReplyMessage = async () => {
    if (!selectedMessageId || !replyText) return;
    try {
      const { error } = await supabase.from('messages').update({
        reply: replyText,
        status: 'replied',
        replied_at: new Date().toISOString()
      }).eq('id', selectedMessageId);
      if (error) throw error;
      toast.success('Reply sent');
      setIsReplyOpen(false);
      setReplyText('');
      setSelectedMessageId(null);
    } catch (error) {
      toast.error('Failed to send reply');
    }
  };

  const filteredClients = clients.filter(c => 
    c.display_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto space-y-10">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-4xl font-serif">
            {view === 'overview' && 'ART Admin Panel'}
            {view === 'clients' && 'Client Directory'}
            {view === 'notices' && 'Notice Management'}
            {view === 'assessments' && 'Assessment Management'}
            {view === 'feedback' && 'Feedback Management'}
            {view === 'messages' && 'Client Messages'}
          </h1>
          <p className="text-muted-foreground font-light tracking-wide">
            {view === 'overview' && 'Premium client oversight and strategic management.'}
            {view === 'clients' && 'Manage and oversee your premium client base.'}
            {view === 'notices' && 'Broadcast announcements to your client network.'}
            {view === 'assessments' && 'Review and manage client assessments.'}
            {view === 'feedback' && 'Create and analyze client feedback forms.'}
            {view === 'messages' && 'Direct communication with your clients.'}
          </p>
        </div>
        
        <div className="flex items-center gap-3">
          <Dialog open={isNoticeOpen} onOpenChange={setIsNoticeOpen}>
            <DialogTrigger
              render={
                <Button variant="outline" className="rounded-full gap-2">
                  <Bell size={16} />
                  Post Notice
                </Button>
              }
            />
            <DialogContent className="sm:max-w-[500px] font-sans">
              <DialogHeader>
                <DialogTitle className="font-serif text-2xl">Broadcast Notice</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest font-semibold">Title</label>
                  <Input 
                    placeholder="Announcement Title" 
                    value={noticeData.title}
                    onChange={e => setNoticeData({...noticeData, title: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest font-semibold">Content</label>
                  <Textarea 
                    placeholder="Write your message here..." 
                    className="min-h-[150px]"
                    value={noticeData.content}
                    onChange={e => setNoticeData({...noticeData, content: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest font-semibold">Target Audience</label>
                  <select 
                    className="w-full p-2 border rounded-md text-sm"
                    value={noticeData.target}
                    onChange={e => setNoticeData({...noticeData, target: e.target.value})}
                  >
                    <option value="all">All Clients</option>
                    <option value="individual">Individual (HNI)</option>
                    <option value="corporate">Corporate</option>
                  </select>
                </div>
                <Button onClick={handlePostNotice} className="w-full bg-[#1a1a1a] text-white rounded-full">
                  Post Announcement
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={isBulkEmailOpen} onOpenChange={setIsBulkEmailOpen}>
            <DialogTrigger
              render={
                <Button className="bg-[#1a1a1a] text-white rounded-full gap-2">
                  <Mail size={16} />
                  Bulk Email
                </Button>
              }
            />
            <DialogContent className="sm:max-w-[600px] font-sans">
              <DialogHeader>
                <DialogTitle className="font-serif text-2xl">Send Bulk Email</DialogTitle>
                <DialogDescription>Send a professional email to multiple clients at once.</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest font-semibold">Subject</label>
                  <Input 
                    placeholder="Email Subject" 
                    value={bulkEmailData.subject}
                    onChange={e => setBulkEmailData({...bulkEmailData, subject: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest font-semibold">Target Group</label>
                  <select 
                    className="w-full p-2 border rounded-md text-sm"
                    value={bulkEmailData.target}
                    onChange={e => setBulkEmailData({...bulkEmailData, target: e.target.value})}
                  >
                    <option value="all">All Active Clients ({clients.length})</option>
                    <option value="individual">Individual Clients ({clients.filter(c => c.client_type === 'individual').length})</option>
                    <option value="corporate">Corporate Clients ({clients.filter(c => c.client_type === 'corporate').length})</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest font-semibold">Message Body</label>
                  <Textarea 
                    placeholder="Write your email content here..." 
                    className="min-h-[250px] font-light leading-relaxed"
                    value={bulkEmailData.body}
                    onChange={e => setBulkEmailData({...bulkEmailData, body: e.target.value})}
                  />
                </div>
                <Button 
                  onClick={handleBulkEmail} 
                  disabled={sendingBulk}
                  className="w-full bg-[#1a1a1a] text-white rounded-full h-12"
                >
                  {sendingBulk ? 'Sending Emails...' : 'Send Bulk Email Now'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </header>

      {view === 'overview' && (
        <>
          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            <StatCard title="Total Clients" value={stats.totalClients} icon={<Users size={20} />} />
            <StatCard title="Assessments" value={stats.activeAssessments} icon={<CheckCircle2 size={20} />} />
            <StatCard title="Total Revenue" value={`$${stats.revenue.toLocaleString()}`} icon={<DollarSign size={20} />} />
            <StatCard title="Pending Invoices" value={stats.pendingInvoices} icon={<TrendingUp size={20} />} />
            <StatCard title="New Messages" value={stats.newMessages} icon={<Mail size={20} />} />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card className="border-[#e5e5e5] shadow-sm">
              <CardHeader>
                <CardTitle className="font-serif text-xl flex items-center justify-between">
                  Recent Clients
                  <Link to="/admin?view=clients" className="text-xs font-sans text-muted-foreground hover:text-[#1a1a1a] underline">View All</Link>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {clients.slice(0, 5).map(client => (
                    <div key={client.id} className="flex items-center justify-between py-2 border-b border-[#f5f5f5] last:border-0">
                      <div>
                        <p className="text-sm font-medium">{client.display_name}</p>
                        <p className="text-xs text-muted-foreground">{client.email}</p>
                      </div>
                      <Link to={`/admin/client/${client.id}`}>
                        <Button variant="ghost" size="sm" className="rounded-full">View</Button>
                      </Link>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="border-[#e5e5e5] shadow-sm">
              <CardHeader>
                <CardTitle className="font-serif text-xl flex items-center justify-between">
                  Recent Notices
                  <Link to="/admin?view=notices" className="text-xs font-sans text-muted-foreground hover:text-[#1a1a1a] underline">Manage</Link>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {notices.slice(0, 5).map(notice => (
                    <div key={notice.id} className="space-y-1 py-2 border-b border-[#f5f5f5] last:border-0">
                      <div className="flex justify-between items-start">
                        <p className="text-sm font-medium">{notice.title}</p>
                        <span className="text-[10px] text-muted-foreground">{safeFormatDate(notice.created_at, 'MMM d')}</span>
                      </div>
                      <p className="text-xs text-muted-foreground line-clamp-1">{notice.content}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}

      {view === 'clients' && (
        <div className="space-y-8">
          <div className="bg-white border border-[#e5e5e5] rounded-2xl shadow-sm overflow-hidden">
            <div className="p-6 border-bottom border-[#e5e5e5] flex items-center justify-between gap-4">
              <div className="flex items-center gap-4 flex-1">
                <h2 className="text-xl font-serif">Active Clients</h2>
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
                  <Input 
                    placeholder="Search by name or email..." 
                    className="pl-10 border-none bg-[#f5f5f5] rounded-full h-11"
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
              
              <Dialog open={isInviteOpen} onOpenChange={setIsInviteOpen}>
                <DialogTrigger
                  render={
                    <Button className="bg-[#1a1a1a] text-white rounded-full gap-2">
                      <UserPlus size={16} />
                      Invite Client
                    </Button>
                  }
                />
                <DialogContent className="sm:max-w-[425px] font-sans">
                  <DialogHeader>
                    <DialogTitle className="font-serif text-2xl">Invite New Client</DialogTitle>
                  </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-widest font-semibold">Full Name</label>
                    <Input 
                      placeholder="Client's Name" 
                      value={inviteData.name}
                      onChange={e => setInviteData({...inviteData, name: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-widest font-semibold">Email Address</label>
                    <Input 
                      type="email"
                      placeholder="client@example.com" 
                      value={inviteData.email}
                      onChange={e => setInviteData({...inviteData, email: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-widest font-semibold">Client Type</label>
                    <select 
                      className="w-full p-2 border rounded-md text-sm"
                      value={inviteData.client_type}
                      onChange={e => setInviteData({...inviteData, client_type: e.target.value})}
                    >
                      <option value="individual">Individual (HNI)</option>
                      <option value="corporate">Corporate</option>
                    </select>
                  </div>
                  <Button onClick={handleInviteClient} className="w-full bg-[#1a1a1a] text-white rounded-full">
                    Send Invite
                  </Button>
                </div>
                </DialogContent>
              </Dialog>
            </div>

            <Table>
              <TableHeader className="bg-[#f9f9f9]">
                <TableRow>
                  <TableHead className="font-serif text-[#1a1a1a]">Client Name</TableHead>
                  <TableHead className="font-serif text-[#1a1a1a]">Type</TableHead>
                  <TableHead className="font-serif text-[#1a1a1a]">Email</TableHead>
                  <TableHead className="font-serif text-[#1a1a1a]">Joined</TableHead>
                  <TableHead className="text-right font-serif text-[#1a1a1a]">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredClients.map((client) => (
                  <TableRow key={client.id} className="hover:bg-[#fafafa] transition-colors">
                    <TableCell className="font-medium">{client.display_name}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={cn(
                        "rounded-full px-3 py-0.5 text-[10px] uppercase tracking-widest",
                        client.client_type === 'corporate' ? "border-blue-200 bg-blue-50 text-blue-700" : "border-amber-200 bg-amber-50 text-amber-700"
                      )}>
                        {client.client_type || 'individual'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground font-light">{client.email}</TableCell>
                    <TableCell className="text-muted-foreground font-light">
                      {safeFormatDate(client.created_at, 'MMM d, yyyy')}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Link to={`/admin/client/${client.id}`}>
                          <Button variant="ghost" size="sm" className="rounded-full gap-2 hover:bg-[#1a1a1a] hover:text-white transition-all">
                            View Profile
                            <ExternalLink size={14} />
                          </Button>
                        </Link>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="rounded-full text-destructive hover:bg-destructive/10"
                          onClick={() => handleRemoveClient(client.id)}
                        >
                          <Trash2 size={14} />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            
            {filteredClients.length === 0 && (
              <div className="p-20 text-center text-muted-foreground font-light italic">
                No clients found matching your search.
              </div>
            )}
          </div>

          {/* Client Invitations Section */}
          <div className="bg-white border border-[#e5e5e5] rounded-2xl shadow-sm overflow-hidden">
            <div className="p-6 border-bottom border-[#e5e5e5]">
              <h2 className="text-xl font-serif">Client Invitations</h2>
              <p className="text-xs text-muted-foreground mt-1">Track invitations sent to prospective clients.</p>
            </div>
            <Table>
              <TableHeader className="bg-[#f9f9f9]">
                <TableRow>
                  <TableHead className="font-serif text-[#1a1a1a]">Name</TableHead>
                  <TableHead className="font-serif text-[#1a1a1a]">Email</TableHead>
                  <TableHead className="font-serif text-[#1a1a1a]">Type</TableHead>
                  <TableHead className="font-serif text-[#1a1a1a]">Sent At</TableHead>
                  <TableHead className="text-right font-serif text-[#1a1a1a]">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {invites.map((invite) => (
                  <TableRow key={invite.id} className={cn(invite.status === 'accepted' && "bg-slate-50/50")}>
                    <TableCell className="font-medium">{invite.name}</TableCell>
                    <TableCell className="text-muted-foreground">{invite.email}</TableCell>
                    <TableCell className="capitalize">{invite.client_type}</TableCell>
                    <TableCell className="text-muted-foreground">
                      {safeFormatDate(invite.created_at, 'MMM d, yyyy')}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Badge variant="outline" className={cn(
                          "rounded-full px-3 py-0.5 text-[10px] uppercase tracking-widest",
                          invite.status === 'accepted' ? "bg-green-50 text-green-700 border-green-100" : "bg-slate-50 text-slate-600 border-slate-200"
                        )}>
                          {invite.status}
                        </Badge>
                        {invite.status === 'pending' && (
                          <>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="rounded-full text-muted-foreground hover:bg-slate-100"
                              onClick={() => handleCopyInviteLink(invite.email)}
                              title="Copy Invite Link"
                            >
                              <Copy size={14} />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="rounded-full text-blue-600 hover:bg-blue-50"
                              onClick={() => handleTestLogin(invite.email)}
                              title="Test Login as this Client"
                            >
                              <ExternalLink size={14} />
                            </Button>
                          </>
                        )}
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="rounded-full text-destructive hover:bg-destructive/10"
                          onClick={() => handleCancelInvite(invite.id)}
                        >
                          <Trash2 size={14} />
                          <span className="ml-1 text-[10px]">{invite.status === 'accepted' ? 'Remove' : 'Cancel'}</span>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            {invites.length === 0 && (
              <div className="p-10 text-center text-muted-foreground font-light italic">
                No invitations sent yet.
              </div>
            )}
          </div>
        </div>
      )}

      {view === 'notices' && (
        <div className="grid grid-cols-1 gap-6">
          {notices.map((notice) => (
            <Card key={notice.id} className="border-[#e5e5e5] shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="font-serif text-xl">{notice.title}</CardTitle>
                  <CardDescription className="flex items-center gap-2 mt-1">
                    <Calendar size={14} />
                    {safeFormatDate(notice.created_at, 'MMMM d, yyyy')}
                    <Badge variant="secondary" className="rounded-full text-[10px] uppercase tracking-widest ml-2">
                      Target: {notice.target}
                    </Badge>
                  </CardDescription>
                </div>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-destructive hover:bg-destructive/5 rounded-full"
                    onClick={async () => {
                      const { error } = await supabase.from('notices').delete().eq('id', notice.id);
                      if (error) {
                        toast.error('Failed to delete notice');
                      } else {
                        toast.success('Notice deleted');
                        // Refresh notices
                        const { data } = await supabase.from('notices').select('*').order('created_at', { ascending: false });
                        if (data) setNotices(data);
                      }
                    }}
                  >
                    Delete
                  </Button>
              </CardHeader>
              <CardContent>
                <p className="text-sm font-light leading-relaxed text-muted-foreground">{notice.content}</p>
              </CardContent>
            </Card>
          ))}
          {notices.length === 0 && (
            <div className="p-20 text-center border border-dashed border-[#e5e5e5] rounded-2xl text-muted-foreground font-light italic">
              No notices posted yet.
            </div>
          )}
        </div>
      )}

      {view === 'assessments' && (
        <AssessmentManager />
      )}

      {view === 'feedback' && (
        <div className="space-y-8">
          <div className="flex justify-end">
            <Dialog open={isFeedbackFormOpen} onOpenChange={setIsFeedbackFormOpen}>
              <DialogTrigger
                render={
                  <Button className="bg-[#1a1a1a] text-white rounded-full gap-2">
                    <MessageSquarePlus size={16} />
                    Create Feedback Form
                  </Button>
                }
              />
              <DialogContent className="sm:max-w-[500px] font-sans">
                <DialogHeader>
                  <DialogTitle className="font-serif text-2xl">New Feedback Form</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-widest font-semibold">Form Title</label>
                    <Input 
                      placeholder="e.g. Quarterly Service Review" 
                      value={feedbackFormData.title}
                      onChange={e => setFeedbackFormData({...feedbackFormData, title: e.target.value})}
                    />
                  </div>
                  <div className="space-y-4">
                    <label className="text-xs uppercase tracking-widest font-semibold">Questions</label>
                    {feedbackFormData.questions.map((q, i) => (
                      <div key={i} className="flex gap-2">
                        <Input 
                          placeholder={`Question ${i + 1}`}
                          value={q}
                          onChange={e => {
                            const newQs = [...feedbackFormData.questions];
                            newQs[i] = e.target.value;
                            setFeedbackFormData({...feedbackFormData, questions: newQs});
                          }}
                        />
                        {feedbackFormData.questions.length > 1 && (
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => {
                              const newQs = feedbackFormData.questions.filter((_, idx) => idx !== i);
                              setFeedbackFormData({...feedbackFormData, questions: newQs});
                            }}
                          >
                            <XCircle size={16} className="text-destructive" />
                          </Button>
                        )}
                      </div>
                    ))}
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full rounded-full border-dashed"
                      onClick={() => setFeedbackFormData({...feedbackFormData, questions: [...feedbackFormData.questions, '']})}
                    >
                      <Plus size={14} className="mr-2" /> Add Question
                    </Button>
                  </div>
                  <Button onClick={handleCreateFeedbackForm} className="w-full bg-[#1a1a1a] text-white rounded-full">
                    Create Form
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid grid-cols-1 gap-6">
            {feedbackForms.map((form) => (
              <Card key={form.id} className="border-[#e5e5e5] shadow-sm">
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle className="font-serif text-xl">{form.title}</CardTitle>
                    <CardDescription>{form.questions.length} Questions</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Badge variant={form.active ? "default" : "secondary"} className="rounded-full">
                      {form.active ? 'Active' : 'Inactive'}
                    </Badge>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-destructive hover:bg-destructive/5 rounded-full"
                      onClick={() => handleDeleteFeedbackForm(form.id!)}
                    >
                      Delete
                    </Button>
                  </div>
                </CardHeader>
              </Card>
            ))}
            {feedbackForms.length === 0 && (
              <div className="p-20 text-center border border-dashed border-[#e5e5e5] rounded-2xl text-muted-foreground font-light italic">
                No feedback forms created yet.
              </div>
            )}
          </div>
        </div>
      )}

      {view === 'messages' && (
        <div className="space-y-6">
          {allMessages.map((msg) => {
            const client = clients.find(c => c.id === msg.client_id);
            return (
              <Card key={msg.id} className="border-[#e5e5e5] shadow-sm">
                <CardHeader className="flex flex-row items-center justify-between">
                  <div className="space-y-1">
                    <CardTitle className="font-serif text-xl">{msg.subject}</CardTitle>
                    <CardDescription>
                      From: {client?.display_name || msg.client_id} • {safeFormatDate(msg.created_at, 'MMM d, h:mm a')}
                    </CardDescription>
                  </div>
                  <Badge variant={msg.status === 'replied' ? "default" : "secondary"} className="rounded-full">
                    {msg.status}
                  </Badge>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm font-light leading-relaxed">{msg.body}</p>
                  {msg.reply && (
                    <div className="mt-4 p-4 bg-[#f9f9f9] rounded-lg border-l-4 border-[#1a1a1a]">
                      <p className="text-[10px] font-bold uppercase tracking-widest mb-1">Your Reply</p>
                      <p className="text-sm font-light italic">"{msg.reply}"</p>
                    </div>
                  )}
                  {msg.status !== 'replied' && (
                    <Button 
                      onClick={() => {
                        setSelectedMessageId(msg.id);
                        setIsReplyOpen(true);
                      }}
                      className="bg-[#1a1a1a] text-white rounded-full gap-2"
                    >
                      <Mail size={16} />
                      Reply to Client
                    </Button>
                  )}
                </CardContent>
              </Card>
            );
          })}
          {allMessages.length === 0 && (
            <div className="p-20 text-center border border-dashed border-[#e5e5e5] rounded-2xl text-muted-foreground font-light italic">
              No messages received yet.
            </div>
          )}
        </div>
      )}

      <Dialog open={isReplyOpen} onOpenChange={setIsReplyOpen}>
        <DialogContent className="sm:max-w-[500px] font-sans">
          <DialogHeader>
            <DialogTitle className="font-serif text-2xl">Reply to Message</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-xs uppercase tracking-widest font-semibold">Your Reply</label>
              <Textarea 
                placeholder="Type your reply here..." 
                className="min-h-[150px]"
                value={replyText}
                onChange={e => setReplyText(e.target.value)}
              />
            </div>
            <Button onClick={handleReplyMessage} className="w-full bg-[#1a1a1a] text-white rounded-full">
              Send Reply
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function StatCard({ title, value, icon }: { title: string, value: string | number, icon: React.ReactNode }) {
  return (
    <Card className="border-[#e5e5e5] shadow-sm">
      <CardContent className="p-6 flex items-center gap-4">
        <div className="p-3 bg-[#f5f5f5] rounded-xl text-[#1a1a1a]">
          {icon}
        </div>
        <div>
          <p className="text-xs uppercase tracking-widest text-muted-foreground font-semibold">{title}</p>
          <p className="text-2xl font-serif mt-1">{value}</p>
        </div>
      </CardContent>
    </Card>
  );
}
