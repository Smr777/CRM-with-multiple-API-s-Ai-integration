import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { motion } from 'motion/react';
import { LogIn } from 'lucide-react';
import { toast } from 'sonner';

export default function Login() {
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const inviteEmail = searchParams.get('invite');

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [isVerificationSent, setIsVerificationSent] = useState(false);
  const [isResetSent, setIsResetSent] = useState(false);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || (!isForgotPassword && !password)) return;
    setLoading(true);
    try {
      if (isForgotPassword) {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/login`,
        });
        if (error) throw error;
        setIsResetSent(true);
      } else if (isSignUp) {
        // Verify invitation first to maintain exclusivity
        const { data: invite, error: inviteError } = await supabase
          .from('invites')
          .select('status')
          .eq('email', email)
          .maybeSingle();

        if (inviteError || !invite) {
          throw new Error('Access to the ART Network is strictly limited to invited partners. Please contact your consultant.');
        }

        if (invite.status === 'accepted') {
          // If already accepted, maybe they are trying to sign up again but should just log in.
          // However, Supabase signUp handles duplicate emails anyway. 
          // We'll let it proceed to auth.signUp which will give a better message or handle it.
        }

        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              full_name: email.split('@')[0],
            },
            emailRedirectTo: `${window.location.origin}/`,
          }
        });
        if (error) throw error;
        
        // If "Confirm Email" is OFF in Supabase, data.session will exist immediately
        if (data.session) {
          toast.success('Account initialized successfully');
          navigate('/');
        } else {
          setIsVerificationSent(true);
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (error) throw error;
        toast.success('Signed in successfully');
        navigate('/');
      }
    } catch (error: any) {
      console.error(error);
      let msg = error.message || 'Authentication failed';
      
      if (msg.includes('rate limit')) {
        msg = 'Email rate limit exceeded. Please disable "Confirm email" in Supabase Auth Settings to sign up instantly.';
      } else if (msg.includes('Invalid login credentials')) {
        msg = 'Incorrect email or password. If you haven\'t set a password yet, please use the Sign Up option.';
      } else if (msg.includes('Email signups are disabled')) {
        msg = 'Signups are currently disabled. Please enable "Allow new users to sign up" in your Supabase Auth Settings.';
      }
      
      toast.error(msg, { duration: 6000 });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-slate-50 p-4 font-sans text-slate-900">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md text-center space-y-8"
      >
        <div className="space-y-1">
          <h1 className="text-5xl font-serif tracking-tight text-slate-900 underline decoration-slate-200 underline-offset-8">ART</h1>
          <p className="text-[10px] uppercase tracking-[0.4em] text-slate-500 font-bold">Private CRM Portal</p>
        </div>

        <div className="p-8 md:p-10 bg-white border border-slate-200 rounded-xl shadow-2xl space-y-8 text-left">
          {isVerificationSent ? (
            <motion.div 
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-8 py-4"
            >
              <div className="w-20 h-20 bg-[#f8f9fa] text-[#1a1a1a] rounded-full flex items-center justify-center mx-auto mb-6 border border-[#eee]">
                <LogIn size={32} strokeWidth={1.5} />
              </div>
              <div className="space-y-4">
                <h2 className="text-2xl font-serif">Security Verification</h2>
                <div className="text-[15px] text-muted-foreground font-light leading-relaxed space-y-4 px-2">
                  <p>A secure confirmation link has been dispatched to your inbox.</p>
                  <p className="font-medium text-[#1a1a1a]">Please authenticate via the link to finalize your access. You will be automatically redirected upon completion.</p>
                </div>
              </div>
              <Button 
                onClick={() => setIsVerificationSent(false)}
                variant="outline"
                className="w-full h-12 rounded-full border-[#e5e5e5] hover:bg-[#fafafa] transition-all"
              >
                Return to Login
              </Button>
            </motion.div>
          ) : isResetSent ? (
            <motion.div 
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-8 py-4"
            >
              <div className="w-20 h-20 bg-[#f8f9fa] text-[#1a1a1a] rounded-full flex items-center justify-center mx-auto mb-6 border border-[#eee]">
                <LogIn size={32} strokeWidth={1.5} />
              </div>
              <div className="space-y-4">
                <h2 className="text-2xl font-serif">Reset Dispatched</h2>
                <div className="text-[15px] text-muted-foreground font-light leading-relaxed">
                  <p>A recovery link has been sent to:</p>
                  <p className="font-medium text-[#1a1a1a] mt-1">{email}</p>
                </div>
              </div>
              <Button 
                onClick={() => {
                  setIsResetSent(false);
                  setIsForgotPassword(false);
                }}
                variant="outline"
                className="w-full h-12 rounded-full border-[#e5e5e5] hover:bg-[#fafafa] transition-all"
              >
                Back to Login
              </Button>
            </motion.div>
          ) : (
            <>
              <div className="space-y-4">
                <h2 className="text-3xl font-bold text-slate-900">
                  {isForgotPassword ? 'Reset Password' : (isSignUp ? 'Sign Up' : 'Sign In')}
                </h2>
                <p className="text-sm text-slate-500 font-medium">
                  {isForgotPassword 
                    ? 'Enter your email to receive a password reset link.'
                    : (isSignUp 
                      ? 'Create your account to access the private portal.' 
                      : 'Welcome back. Please enter your details.')}
                </p>
              </div>
              
              <form onSubmit={handleAuth} className="space-y-5">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-widest ml-1">Email Address</label>
                  <input 
                    type="email" 
                    placeholder="email@example.com"
                    className="w-full h-12 px-4 rounded-lg border-2 border-slate-100 bg-slate-50 focus:bg-white focus:border-slate-900 outline-none transition-all text-sm font-medium"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    required
                  />
                </div>

                {!isForgotPassword && (
                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center px-1">
                      <label className="text-xs font-bold text-slate-700 uppercase tracking-widest">Password</label>
                      {!isSignUp && (
                        <button 
                          type="button"
                          onClick={() => setIsForgotPassword(true)}
                          className="text-xs font-bold text-slate-900 hover:underline"
                        >
                          Forgot password?
                        </button>
                      )}
                    </div>
                    <input 
                      type="password" 
                      placeholder="••••••••"
                      className="w-full h-12 px-4 rounded-lg border-2 border-slate-100 bg-slate-50 focus:bg-white focus:border-slate-900 outline-none transition-all text-sm font-medium"
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      required={!isForgotPassword}
                    />
                  </div>
                )}

                <Button 
                  type="submit"
                  disabled={loading}
                  className="w-full h-12 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-bold transition-all text-sm shadow-lg shadow-slate-200 active:scale-[0.98]"
                >
                  {loading ? 'Processing...' : (isForgotPassword ? 'Get Reset Link' : (isSignUp ? 'Create Account' : 'Login'))}
                </Button>
              </form>

              <div className="pt-6 border-t border-slate-100 italic text-center">
                <button 
                  type="button" 
                  onClick={() => {
                    if (isForgotPassword) {
                      setIsForgotPassword(false);
                    } else {
                      setIsSignUp(!isSignUp);
                    }
                  }}
                  className="text-sm font-bold text-slate-500 hover:text-slate-900 transition-colors"
                >
                  {isForgotPassword 
                    ? 'Wait, I remember my password' 
                    : (isSignUp ? 'Already member? Sign In' : "Don't have an account? Sign Up")}
                </button>
              </div>
            </>
          )}
        </div>

        <div className="space-y-1 pt-4">
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-[0.3em]">
            Restricted Access Control
          </p>
          <p className="text-[10px] text-slate-400 font-medium italic">
            ART Network Private Portal
          </p>
        </div>
      </motion.div>
    </div>
  );
}
