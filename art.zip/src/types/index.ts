export interface UserProfile {
  id: string;
  email: string;
  display_name: string;
  role: 'admin' | 'client';
  client_type?: 'individual' | 'corporate';
  welcome_instructions?: string;
  welcome_packet_url?: string;
  created_at: string;
}

export interface Invoice {
  id: string;
  client_id: string;
  amount: number;
  status: 'paid' | 'unpaid' | 'verifying';
  date: string;
  pdf_url?: string;
  proof_of_payment_url?: string;
  proof_history?: string[];
  description: string;
}

export interface Contract {
  id: string;
  client_id: string;
  content: string;
  signed_at?: string;
  signature?: string;
  status: 'pending' | 'signed';
  duration_days?: number;
  session_duration?: string;
  session_date_time?: string;
}

export interface AssessmentTemplate {
  id: string;
  title: string;
  description: string;
  questions: AssessmentQuestion[];
  created_at: string;
}

export interface AssessmentQuestion {
  id: string;
  text: string;
  options: string[];
}

export interface ClientAssessment {
  id: string;
  client_id: string;
  template_id?: string;
  title: string;
  description: string;
  questions: ClientAssessmentQuestion[];
  status: 'pending' | 'completed';
  submitted_at?: string;
  updated_at: string;
  report_url?: string;
}

export interface ClientAssessmentQuestion {
  id: string;
  text: string;
  options: string[];
  answer?: string;
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  created_at: string;
  target: 'all' | 'individual' | 'corporate';
}

export interface FeedbackForm {
  id: string;
  title: string;
  questions: string[];
  active: boolean;
}

export interface FeedbackResponse {
  id: string;
  form_id: string;
  client_id: string;
  responses: string[];
  submitted_at: string;
  ai_analysis?: {
    sentiment: string;
    patterns: string[];
    suggestions: string[];
    insights: string;
  };
}

export interface Message {
  id: string;
  client_id: string;
  subject: string;
  body: string;
  created_at: string;
  status: 'new' | 'read' | 'replied';
  reply?: string;
  replied_at?: string;
}
