-- Supabase Schema for ART CRM

-- 1. Users Profile Table (linked to auth.users)
CREATE TABLE IF NOT EXISTS public.users (
  id UUID REFERENCES auth.users(id) PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  display_name TEXT,
  role TEXT DEFAULT 'client', -- 'admin' or 'client'
  client_type TEXT DEFAULT 'individual', -- 'individual' or 'corporate'
  welcome_packet_url TEXT,
  welcome_instructions TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Invoices Table
CREATE TABLE IF NOT EXISTS public.invoices (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id UUID REFERENCES public.users(id) ON DELETE CASCADE NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  status TEXT DEFAULT 'unpaid', -- 'paid', 'unpaid', 'verifying'
  date TIMESTAMPTZ DEFAULT NOW(),
  description TEXT,
  pdf_url TEXT,
  proof_of_payment_url TEXT,
  proof_history JSONB DEFAULT '[]'::JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Assessment Templates Table
CREATE TABLE IF NOT EXISTS public.assessment_templates (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  questions JSONB DEFAULT '[]'::JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Client Assessments Table
CREATE TABLE IF NOT EXISTS public.client_assessments (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id UUID REFERENCES public.users(id) ON DELETE CASCADE NOT NULL,
  template_id UUID REFERENCES public.assessment_templates(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  description TEXT,
  questions JSONB DEFAULT '[]'::JSONB,
  status TEXT DEFAULT 'pending', -- 'pending', 'completed'
  submitted_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  report_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Notices Table
CREATE TABLE IF NOT EXISTS public.notices (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  target TEXT DEFAULT 'all', -- 'all', 'individual', 'corporate'
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Invites Table
CREATE TABLE IF NOT EXISTS public.invites (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  client_type TEXT DEFAULT 'individual',
  status TEXT DEFAULT 'pending', -- 'pending', 'accepted'
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Feedback Forms Table
CREATE TABLE IF NOT EXISTS public.feedback_forms (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  questions JSONB DEFAULT '[]'::JSONB,
  active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Feedback Responses Table
CREATE TABLE IF NOT EXISTS public.feedback_responses (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  form_id UUID REFERENCES public.feedback_forms(id) ON DELETE CASCADE NOT NULL,
  client_id UUID REFERENCES public.users(id) ON DELETE CASCADE NOT NULL,
  responses JSONB DEFAULT '[]'::JSONB,
  submitted_at TIMESTAMPTZ DEFAULT NOW(),
  ai_analysis JSONB
);

-- 9. Messages Table
CREATE TABLE IF NOT EXISTS public.messages (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id UUID REFERENCES public.users(id) ON DELETE CASCADE NOT NULL,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  status TEXT DEFAULT 'new', -- 'new', 'read', 'replied'
  reply TEXT,
  replied_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10. File Uploads (Metadata Tracking)
CREATE TABLE IF NOT EXISTS public.file_uploads (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE NOT NULL,
  type TEXT NOT NULL, -- 'payment-proof', 'welcome-packet', 'assessment-report'
  context_id TEXT, -- e.g. invoice_id or assessment_id
  file_name TEXT,
  file_type TEXT,
  storage_path TEXT,
  download_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security (RLS) handles by the application or through default policies
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assessment_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.client_assessments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invites ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.feedback_forms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.feedback_responses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.file_uploads ENABLE ROW LEVEL SECURITY;

-- Simple RLS Policies (Allow authenticated users to read and own their data)
-- For this ART CRM, we might want more granular roles eventually.

CREATE POLICY "Allow public read of profiles" ON public.users FOR SELECT USING (true);
CREATE POLICY "Users can update own profile" ON public.users FOR UPDATE USING (auth.uid() = id);

-- Helper for admin check
-- Refined to include a hardcoded email fallback for safety
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'admin' OR
    (SELECT email FROM auth.users WHERE id = auth.uid()) = 'sidharthamishra6@gmail.com'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Invites: Only admin can manage
CREATE POLICY "Admin can manage invites" ON public.invites
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- Notices: Public read, Admin write
CREATE POLICY "Anyone can read notices" ON public.notices FOR SELECT USING (true);
CREATE POLICY "Admin can manage notices" ON public.notices
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- Invoices: Admin can manage all, clients can read own
CREATE POLICY "Admin can manage invoices" ON public.invoices
  USING (public.is_admin())
  WITH CHECK (public.is_admin());
CREATE POLICY "Clients can read own invoices" ON public.invoices FOR SELECT
  USING (client_id = auth.uid() OR public.is_admin());
CREATE POLICY "Clients can update own invoices for adding proof" ON public.invoices FOR UPDATE
  USING (client_id = auth.uid())
  WITH CHECK (client_id = auth.uid());

-- Assessments: Admin manage all, clients access own
CREATE POLICY "Admin can manage assessment templates" ON public.assessment_templates
  USING (public.is_admin())
  WITH CHECK (public.is_admin());
CREATE POLICY "Anyone can read templates" ON public.assessment_templates FOR SELECT USING (true);

CREATE POLICY "Admin can manage client assessments" ON public.client_assessments
  USING (public.is_admin())
  WITH CHECK (public.is_admin());
CREATE POLICY "Clients can access own assessments" ON public.client_assessments
  USING (client_id = auth.uid() OR public.is_admin());

-- Feedback: Admin manage forms, clients respond
CREATE POLICY "Anyone can read active feedback forms" ON public.feedback_forms FOR SELECT USING (active = true OR public.is_admin());
CREATE POLICY "Admin manage feedback forms" ON public.feedback_forms
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY "Clients can manage own responses" ON public.feedback_responses
  USING (client_id = auth.uid() OR public.is_admin())
  WITH CHECK (client_id = auth.uid() OR public.is_admin());

-- Messages
CREATE POLICY "Users can manage own messages" ON public.messages
  USING (client_id = auth.uid() OR public.is_admin())
  WITH CHECK (client_id = auth.uid() OR public.is_admin());

-- File Uploads
CREATE POLICY "Users can manage own file uploads" ON public.file_uploads
  USING (user_id = auth.uid() OR public.is_admin())
  WITH CHECK (user_id = auth.uid() OR public.is_admin());

-- Users Table: Admin can delete/manage others
CREATE POLICY "Admin manage all profiles" ON public.users
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- TRIGGER TO CREATE PROFILE ON SIGNUP
-- This function will be called when a user signs up.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.users (id, email, display_name, role)
  VALUES (new.id, new.email, new.raw_user_meta_data->>'full_name', 'client')
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    display_name = EXCLUDED.display_name;
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();
